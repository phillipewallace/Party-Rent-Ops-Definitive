import React, { useState, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { BarChart3, TrendingUp, Download, Calendar, Package, Users, DollarSign, FileText } from "lucide-react";
import { useERP } from "@/context/ERPApiContext";

const Relatorios = () => {
  const { products, orders, clients, getTransactions } = useERP();
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadTransactions = async () => {
      try {
        const data = await getTransactions();
        setTransactions(data);
      } catch (error) {
        console.error('Erro ao carregar transações:', error);
      } finally {
        setLoading(false);
      }
    };
    loadTransactions();
  }, [getTransactions]);

  // Calcular dados reais para gráfico de receitas mensais - MOVED BEFORE CONDITIONAL RETURN
  const monthlyRevenue = React.useMemo(() => {
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const currentDate = new Date();
    const chartData = [];

    for (let i = 5; i >= 0; i--) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
      const monthKey = months[date.getMonth()];
      
      // Receitas do mês (ordens finalizadas)
      const monthlyOrderRevenue = orders
        .filter(order => {
          if (order.status !== 'finalizado') return false;
          const orderDate = new Date(order.created_at);
          return orderDate.getMonth() === date.getMonth() && 
                 orderDate.getFullYear() === date.getFullYear();
        })
        .reduce((sum, order) => sum + (order.total_amount || 0), 0);

      // Despesas do mês
      const monthlyExpenses = transactions
        .filter(transaction => {
          if (transaction.type !== 'despesa') return false;
          const transactionDate = new Date(transaction.date);
          return transactionDate.getMonth() === date.getMonth() && 
                 transactionDate.getFullYear() === date.getFullYear();
        })
        .reduce((sum, transaction) => sum + (Number(transaction.amount) || 0), 0);

      chartData.push({
        month: monthKey,
        receita: monthlyOrderRevenue,
        despesa: monthlyExpenses
      });
    }

  return chartData;
  }, [orders, transactions]);

  // Top produtos mais locados - MOVED BEFORE CONDITIONAL RETURN
  const productStats = React.useMemo(() => products.map(product => {
    const timesRented = orders
      .flatMap(os => os.products || [])
      .filter(p => p.product_id === product.id)
      .reduce((acc, p) => acc + (p.quantity || 0), 0);
      
    const revenue = orders
      .flatMap(os => os.products || [])
      .filter(p => p.product_id === product.id)
      .reduce((acc, p) => acc + (p.total || 0), 0);
      
    return {
      name: product.name,
      timesRented,
      revenue,
      category: product.category,
    };
  }).sort((a, b) => b.revenue - a.revenue), [products, orders]);

  // Distribuição por categoria - MOVED BEFORE CONDITIONAL RETURN
  const categoryData = React.useMemo(() => products.reduce((acc, product) => {
    const existing = acc.find(item => item.category === product.category);
    if (existing) {
      existing.value += 1;
    } else {
      acc.push({
        category: product.category,
        value: 1,
      });
    }
    return acc;
  }, [] as { category: string; value: number }[]), [products]);

  const COLORS = ['#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444'];

  // Status das OS - MOVED BEFORE CONDITIONAL RETURN
  const osStatusData = React.useMemo(() => [
    { status: 'Orçamento', count: orders.filter(os => os.status === 'orcamento').length },
    { status: 'Confirmado', count: orders.filter(os => os.status === 'confirmado').length },
    { status: 'Em Andamento', count: orders.filter(os => os.status === 'em_andamento').length },
    { status: 'Finalizado', count: orders.filter(os => os.status === 'finalizado').length },
  ].filter(item => item.count > 0), [orders]);

  // Métricas principais - MOVED BEFORE CONDITIONAL RETURN
  const totalRevenue = React.useMemo(() => orders.reduce((acc, os) => acc + (os.total_amount || 0), 0), [orders]);
  const totalExpenses = React.useMemo(() => transactions
    .filter(t => t.type === 'despesa')
    .reduce((acc, t) => acc + (Number(t.amount) || 0), 0), [transactions]);
  const profit = React.useMemo(() => totalRevenue - totalExpenses, [totalRevenue, totalExpenses]);
  const profitMargin = React.useMemo(() => totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0, [profit, totalRevenue]);

  if (loading) {
    return (
      <Layout>
        <div className="p-6 space-y-6 bg-background min-h-screen">
          <div className="flex justify-center items-center h-64">
            <div className="text-muted-foreground">Carregando relatórios...</div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-6 space-y-6 bg-background min-h-screen">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Relatórios</h1>
            <p className="text-muted-foreground">Análise completa do desempenho do seu negócio</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              Filtrar Período
            </Button>
            <Button className="bg-erp-primary hover:bg-erp-primary-light text-white">
              <Download className="h-4 w-4 mr-2" />
              Exportar PDF
            </Button>
          </div>
        </div>

        {/* Métricas Principais */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-erp-success/20 bg-gradient-to-br from-erp-success/5 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Receita Total</p>
                  <p className="text-2xl font-bold text-foreground">R$ {totalRevenue.toFixed(2)}</p>
                  <p className="text-xs text-erp-success mt-1">+15% vs período anterior</p>
                </div>
                <DollarSign className="h-8 w-8 text-erp-success" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-erp-primary/20 bg-gradient-to-br from-erp-primary/5 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Lucro Líquido</p>
                  <p className="text-2xl font-bold text-foreground">R$ {profit.toFixed(2)}</p>
                  <p className="text-xs text-erp-success mt-1">Margem: {profitMargin.toFixed(1)}%</p>
                </div>
                <TrendingUp className="h-8 w-8 text-erp-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">OS Ativas</p>
                  <p className="text-2xl font-bold text-foreground">
                    {orders.filter(os => os.status === 'em_andamento' || os.status === 'confirmado').length}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">De {orders.length} total</p>
                </div>
                <FileText className="h-8 w-8 text-erp-warning" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Taxa de Ocupação</p>
                  <p className="text-2xl font-bold text-foreground">
                    {products.length > 0 ? 
                      ((products.reduce((acc, p) => acc + (p.quantity - p.available), 0) / 
                        products.reduce((acc, p) => acc + p.quantity, 0)) * 100).toFixed(1) : '0.0'}%
                  </p>
                  <p className="text-xs text-erp-success mt-1">Equipamentos em uso</p>
                </div>
                <Package className="h-8 w-8 text-erp-secondary" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Receitas vs Despesas Mensais */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Receitas vs Despesas (Últimos 6 meses)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyRevenue}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => [`R$ ${value.toFixed(2)}`, '']}
                    labelFormatter={(label) => `Mês: ${label}`}
                  />
                  <Bar dataKey="receita" fill="#10B981" name="Receita" />
                  <Bar dataKey="despesa" fill="#EF4444" name="Despesa" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Distribuição por Categoria */}
          <Card>
            <CardHeader>
              <CardTitle>Produtos por Categoria</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ category, percent }: any) => `${category} (${(percent * 100).toFixed(0)}%)`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Status das OS */}
          <Card>
            <CardHeader>
              <CardTitle>Status das Ordens de Serviço</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={osStatusData} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="status" type="category" width={100} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3B82F6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Top Produtos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Top Produtos por Receita
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {productStats.slice(0, 5).map((product, index) => (
                <div key={product.name} className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-erp-primary text-white text-sm font-bold">
                      #{index + 1}
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground">{product.name}</h4>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <Badge variant="outline">{product.category}</Badge>
                        <span>{product.timesRented} locações</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-foreground">R$ {product.revenue.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">
                      {product.timesRented > 0 ? 
                        `R$ ${(product.revenue / product.timesRented).toFixed(2)} por locação` : 
                        'Nunca locado'
                      }
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Análise de Clientes */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Top Clientes por Valor
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {clients.map(client => {
                  const clientOS = orders.filter(os => os.client_id === client.id);
                  const totalValue = clientOS.reduce((acc, os) => acc + (os.total_amount || 0), 0);
                  
                  return totalValue > 0 ? (
                    <div key={client.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                      <div>
                        <p className="font-medium text-foreground">{client.name}</p>
                        <p className="text-sm text-muted-foreground">{clientOS.length} OS</p>
                      </div>
                      <p className="font-bold text-foreground">R$ {totalValue.toFixed(2)}</p>
                    </div>
                  ) : null;
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Resumo do Período</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 rounded-lg bg-secondary/30">
                  <span className="text-sm font-medium">Produtos cadastrados</span>
                  <span className="font-bold">{products.length}</span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-lg bg-secondary/30">
                  <span className="text-sm font-medium">Clientes ativos</span>
                  <span className="font-bold">{clients.length}</span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-lg bg-secondary/30">
                  <span className="text-sm font-medium">OS finalizadas</span>
                  <span className="font-bold">
                    {orders.filter(os => os.status === 'finalizado').length}
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-lg bg-secondary/30">
                  <span className="text-sm font-medium">Ticket médio</span>
                  <span className="font-bold">
                    R$ {orders.length > 0 ? 
                      (totalRevenue / orders.length).toFixed(2) : 
                      '0.00'
                    }
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Relatorios;