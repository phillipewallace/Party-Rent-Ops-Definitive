import React, { useState, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Truck, RotateCcw, Package, MapPin, User, Trash2 } from "lucide-react";
import { AgendaModal } from "@/components/modals";
import { useERP } from "@/context/ERPApiContext";
import { agendaApi } from "@/services/api";
import { AlertDialogConfirm } from "@/components/ui/alert-dialog-confirm";

const Agenda = () => {
  const { orders, clients } = useERP();
  const [selectedDate, setSelectedDate] = useState('');
  const [agendaModalOpen, setAgendaModalOpen] = useState(false);
  const [events, setEvents] = useState<any[]>([]);
  const [backendEvents, setBackendEvents] = useState<any[]>([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [eventToDelete, setEventToDelete] = useState<any>(null);
  
  // Generate calendar events based on orders
  const generateCalendarEvents = () => {
    const calendarEvents: any[] = [];

    orders.forEach(order => {
      // Only show events for orders that are not closed/finalized
      if (order.status === 'finalizado') {
        return; // Skip closed orders
      }

      const client = clients.find(c => c.id === order.client_id);
      
      // Delivery event
      calendarEvents.push({
        id: `delivery-${order.id}`,
        title: `Entrega - OS #${order.order_number || order.id.slice(-6)}`,
        type: 'entrega',
        date: order.start_date,
        time: '09:00',
        status: 'agendado',
        os_id: order.id,
        client_id: order.client_id,
        description: `Entrega de equipamentos para ${client?.name || 'Cliente'}`
      });

      // Pickup event
      calendarEvents.push({
        id: `pickup-${order.id}`,
        title: `Retirada - OS #${order.order_number || order.id.slice(-6)}`,
        type: 'retirada',
        date: order.end_date,
        time: '14:00',
        status: 'agendado',
        os_id: order.id,
        client_id: order.client_id,
        description: `Retirada de equipamentos de ${client?.name || 'Cliente'}`
      });
    });

    return calendarEvents;
  };

  // Load backend events
  const loadBackendEvents = async () => {
    try {
      const backendData = await agendaApi.getEvents();
      setBackendEvents(backendData);
    } catch (error) {
      console.error('Erro ao carregar eventos da agenda:', error);
      setBackendEvents([]); // Set empty array on error
    }
  };

  useEffect(() => {
    loadBackendEvents();
  }, []);

  useEffect(() => {
    const generatedEvents = generateCalendarEvents();
    const allEvents = [...generatedEvents, ...backendEvents];
    setEvents(allEvents);
  }, [orders, clients, backendEvents]);

  const eventsForDate = selectedDate 
    ? events.filter(event => event.date === selectedDate)
    : events;

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'entrega': return <Truck className="h-4 w-4" />;
      case 'retirada': return <RotateCcw className="h-4 w-4" />;
      case 'manutencao': return <Package className="h-4 w-4" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'entrega': return 'bg-erp-primary text-white';
      case 'retirada': return 'bg-erp-warning text-white';
      case 'manutencao': return 'bg-erp-danger text-white';
      default: return 'bg-erp-secondary text-foreground';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'agendado': return 'bg-blue-100 text-blue-800';
      case 'em_andamento': return 'bg-yellow-100 text-yellow-800';
      case 'concluido': return 'bg-green-100 text-green-800';
      case 'cancelado': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleDeleteEvent = (event: any) => {
    setEventToDelete(event);
    setDeleteDialogOpen(true);
  };

  const confirmDeleteEvent = async () => {
    if (eventToDelete && eventToDelete.id && !eventToDelete.id.includes('delivery') && !eventToDelete.id.includes('pickup')) {
      try {
        await agendaApi.deleteEvent(eventToDelete.id);
        await loadBackendEvents();
        setDeleteDialogOpen(false);
        setEventToDelete(null);
      } catch (error) {
        console.error('Erro ao excluir evento:', error);
      }
    }
  };

  return (
    <Layout>
      <div className="p-6 space-y-6 bg-background min-h-screen">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Agenda</h1>
            <p className="text-muted-foreground">
              {selectedDate 
                ? `Eventos para ${new Date(selectedDate).toLocaleDateString('pt-BR')}`
                : 'Todos os eventos agendados'
              }
            </p>
          </div>
          <Button 
            className="bg-erp-primary hover:bg-erp-primary-light text-white"
            onClick={() => setAgendaModalOpen(true)}
          >
            <Calendar className="h-4 w-4 mr-2" />
            Novo Agendamento
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total de Eventos</p>
                  <p className="text-2xl font-bold text-foreground">{events.length}</p>
                </div>
                <Calendar className="h-8 w-8 text-erp-primary" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Entregas</p>
                  <p className="text-2xl font-bold text-foreground">
                    {events.filter(e => e.type === 'entrega').length}
                  </p>
                </div>
                <Truck className="h-8 w-8 text-erp-primary" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Retiradas</p>
                  <p className="text-2xl font-bold text-foreground">
                    {events.filter(e => e.type === 'retirada').length}
                  </p>
                </div>
                <RotateCcw className="h-8 w-8 text-erp-warning" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Hoje</p>
                  <p className="text-2xl font-bold text-foreground">
                    {events.filter(e => e.date === new Date().toISOString().split('T')[0]).length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-erp-success" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Calendar and Events */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Calendário</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <input 
                  type="date" 
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full p-2 border rounded"
                />
                {selectedDate && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => setSelectedDate('')}
                  >
                    Mostrar todos os eventos
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>
                {selectedDate 
                  ? `Eventos para ${new Date(selectedDate).toLocaleDateString('pt-BR')}`
                  : 'Todos os Eventos'
                }
              </CardTitle>
            </CardHeader>
            <CardContent>
              {eventsForDate.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>{selectedDate 
                    ? 'Nenhum evento agendado para esta data'
                    : 'Nenhum evento agendado'
                  }</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {eventsForDate.map((event, index) => {
                    const client = clients.find(c => c.id === event.client_id);
                    return (
                      <div key={index} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center gap-3">
                            <Badge className={getEventColor(event.type)}>
                              {getEventIcon(event.type)}
                              <span className="ml-1 capitalize">{event.type}</span>
                            </Badge>
                            <Badge className={getStatusColor(event.status)}>
                              {event.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              {event.time}
                            </div>
                            {!event.id.includes('delivery') && !event.id.includes('pickup') && (
                              <Button 
                                variant="destructive" 
                                size="sm"
                                onClick={() => handleDeleteEvent(event)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                        
                        <h3 className="font-semibold text-lg mb-2">{event.title}</h3>
                        
                        <div className="space-y-2 text-sm">
                          {client && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <User className="h-4 w-4" />
                              {client.name}
                            </div>
                          )}
                          {event.description && (
                            <p className="text-muted-foreground">{event.description}</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <AgendaModal 
          open={agendaModalOpen}
          onOpenChange={(open) => {
            setAgendaModalOpen(open);
            if (!open) loadBackendEvents();
          }}
          selectedDate={selectedDate}
        />

        <AlertDialogConfirm
          open={deleteDialogOpen}
          onOpenChange={setDeleteDialogOpen}
          onConfirm={confirmDeleteEvent}
          title="Excluir Evento"
          description={`Tem certeza que deseja excluir o evento "${eventToDelete?.title}"? Esta ação não pode ser desfeita.`}
        />
      </div>
    </Layout>
  );
};

export default Agenda;