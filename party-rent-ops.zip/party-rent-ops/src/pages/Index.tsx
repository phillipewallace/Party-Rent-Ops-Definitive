import { Layout } from "@/components/layout/Layout";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { FinancialChart } from "@/components/dashboard/FinancialChart";
import { PendingPayments } from "@/components/dashboard/PendingPayments";
import { DollarSign, TrendingUp, TrendingDown, Package, AlertCircle } from "lucide-react";
import { useERP } from "@/context/ERPApiContext";
import { useEffect } from "react";

const Index = () => {
  const { 
    metrics,
    loadingMetrics,
    getMetrics,
    refreshAll
  } = useERP();

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  if (loadingMetrics || !metrics) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-2 text-muted-foreground">Carregando dashboard...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-6 space-y-6 min-h-screen bg-background">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Visão geral do seu negócio de aluguel de equipamentos</p>
        </div>

        {/* Métricas principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Receita Mensal"
            value={`R$ ${metrics.monthlyRevenue.toFixed(2)}`}
            icon={TrendingUp}
            variant={metrics.monthlyRevenue > 0 ? "success" : "danger"}
            trend={{ value: 12, isPositive: true }}
          />
          <MetricCard
            title="Gastos Mensais"
            value={`R$ ${metrics.monthlyExpenses.toFixed(2)}`}
            icon={TrendingDown}
            variant="danger"
            trend={{ value: -8, isPositive: true }}
          />
          <MetricCard
            title="Produtos em Estoque"
            value={metrics.productsInStock.toString()}
            icon={Package}
            variant="default"
          />
          <MetricCard
            title="Pagamentos Pendentes"
            value={metrics.pendingPayments.toString()}
            icon={AlertCircle}
            variant="warning"
          />
        </div>

        {/* Gráficos e informações */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <FinancialChart />
          <PendingPayments />
        </div>
      </div>
    </Layout>
  );
};

export default Index;
