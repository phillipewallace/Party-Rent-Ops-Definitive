import React, { useState, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, TrendingDown, CreditCard, AlertCircle, Plus, Calendar, Trash2 } from "lucide-react";
import { FinancialModal } from "@/components/modals";
import { toast } from "@/hooks/use-toast";
import { useERP } from "@/context/ERPApiContext";
import { AlertDialogConfirm } from "@/components/ui/alert-dialog-confirm";

const Financeiro = () => {
  const { 
    getTransactions,
    createTransaction,
    deleteTransaction,
    getPendingPayments,
    orders, 
    clients,
    markPaymentAsPaid
  } = useERP();

  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [selectedTransaction, setSelectedTransaction] = useState<any>(undefined);
  const [financialFilter, setFinancialFilter] = useState<"all" | "receita" | "despesa">("all");
  const [transactions, setTransactions] = useState<any[]>([]);
  const [pendingPayments, setPendingPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<any>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [transactionsData, paymentsData] = await Promise.all([
        getTransactions(),
        getPendingPayments()
      ]);
      setTransactions(transactionsData);
      setPendingPayments(paymentsData);
    } catch (error) {
      console.error('Erro ao carregar dados financeiros:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredTransactions = transactions.filter(t => 
    financialFilter === "all" || t.type === financialFilter
  );

  const totalRevenue = transactions.filter(t => t.type === 'receita').reduce((acc, t) => acc + Number(t.amount || 0), 0);
  const totalExpenses = transactions.filter(t => t.type === 'despesa').reduce((acc, t) => acc + Number(t.amount || 0), 0);
  const netProfit = totalRevenue - totalExpenses;

  const handleMarkAsPaid = async (orderId: string) => {
    try {
      const order = orders.find(o => o.id === orderId);
      if (order && order.remaining_amount > 0) {
        await markPaymentAsPaid(
          orderId,
          order.remaining_amount,
          `Pagamento completo OS #${order.order_number || order.id.slice(-6)}`
        );
        await loadData();
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível confirmar o pagamento.",
        variant: "destructive",
      });
    }
  };

  const openModal = (mode: "create" | "edit", transaction?: any) => {
    setModalMode(mode);
    setSelectedTransaction(transaction);
    setModalOpen(true);
  };

  const handleDeleteTransaction = (transaction: any) => {
    setTransactionToDelete(transaction);
    setDeleteDialogOpen(true);
  };

  const confirmDeleteTransaction = async () => {
    if (transactionToDelete) {
      try {
        await deleteTransaction(transactionToDelete.id);
        await loadData();
        setDeleteDialogOpen(false);
        setTransactionToDelete(null);
      } catch (error) {
        toast({
          title: "Erro",
          description: "Não foi possível excluir a transação.",
          variant: "destructive",
        });
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pago': return 'bg-green-100 text-green-800';
      case 'pendente': return 'bg-yellow-100 text-yellow-800';
      case 'atrasado': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="p-6 space-y-6 bg-background min-h-screen">
          <div className="flex justify-center items-center h-64">
            <div className="text-muted-foreground">Carregando dados financeiros...</div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-6 space-y-6 bg-background min-h-screen">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Financeiro</h1>
            <p className="text-muted-foreground">Controle suas receitas e despesas</p>
          </div>
          <Button 
            className="bg-erp-primary hover:bg-erp-primary-light text-white"
            onClick={() => openModal("create")}
          >
            <Plus className="h-4 w-4 mr-2" />
            Nova Transação
          </Button>
        </div>

        {/* Métricas Financeiras */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Receitas</p>
                  <p className="text-2xl font-bold text-erp-success">R$ {Number(totalRevenue || 0).toFixed(2)}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-erp-success" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Despesas</p>
                  <p className="text-2xl font-bold text-erp-danger">R$ {Number(totalExpenses || 0).toFixed(2)}</p>
                </div>
                <TrendingDown className="h-8 w-8 text-erp-danger" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Lucro Líquido</p>
                  <p className={`text-2xl font-bold ${netProfit >= 0 ? 'text-erp-success' : 'text-erp-danger'}`}>
                    R$ {Number(netProfit || 0).toFixed(2)}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-erp-primary" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pagamentos Pendentes</p>
                  <p className="text-2xl font-bold text-erp-warning">{pendingPayments.length}</p>
                </div>
                <AlertCircle className="h-8 w-8 text-erp-warning" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pagamentos Pendentes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Pagamentos Pendentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {/* Pagamentos pendentes das OS (remaining_amount > 0) */}
              {orders
                .filter(order => (order.remaining_amount || 0) > 0)
                .map(order => {
                  const client = clients.find(c => c.id === order.client_id);
                  return (
                    <div key={`order-${order.id}`} className="flex justify-between items-center p-3 bg-secondary/30 rounded">
                      <div>
                        <p className="font-medium">{client?.name}</p>
                        <p className="text-sm text-muted-foreground">
                          OS #{order.order_number || order.id.slice(-6)} - Vencimento: {order.end_date}
                        </p>
                        <Badge variant="outline" className="text-xs mt-1">Saldo Pendente</Badge>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-erp-primary">R$ {Number(order.remaining_amount || 0).toFixed(2)}</span>
                        <Button size="sm" onClick={() => handleMarkAsPaid(order.id)}>
                          Confirmar Pagamento Completo
                        </Button>
                      </div>
                    </div>
                  );
                })
              }
              
              {/* Pagamentos específicos pendentes (status = 'pendente') */}
              {pendingPayments
                .filter(payment => payment.status === 'pendente')
                .map((payment: any) => {
                  const order = orders.find(o => o.id === payment.order_id);
                  const client = clients.find(c => c.id === order?.client_id);
                  return (
                    <div key={`payment-${payment.id}`} className="flex justify-between items-center p-3 bg-yellow-50 rounded border border-yellow-200">
                      <div>
                        <p className="font-medium">{client?.name || 'Cliente não encontrado'}</p>
                        <p className="text-sm text-muted-foreground">
                          OS #{order?.order_number || payment.order_id?.slice(-6)} - {payment.type} - {payment.method}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Vencimento: {new Date(payment.due_date).toLocaleDateString('pt-BR')}
                        </p>
                        <Badge variant="outline" className="text-xs mt-1">Pagamento Específico</Badge>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-erp-warning">R$ {Number(payment.amount || 0).toFixed(2)}</span>
                        <Button size="sm" variant="outline" onClick={() => handleMarkAsPaid(payment.order_id)}>
                          Confirmar Pagamento
                        </Button>
                      </div>
                    </div>
                  );
                })
              }
              
              {orders.filter(order => (order.remaining_amount || 0) > 0).length === 0 && 
               pendingPayments.filter(payment => payment.status === 'pendente').length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <CreditCard className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>Nenhum pagamento pendente</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Transações */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Transações Financeiras</CardTitle>
              <div className="flex gap-2">
                <Button
                  variant={financialFilter === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFinancialFilter("all")}
                >
                  Todas
                </Button>
                <Button
                  variant={financialFilter === "receita" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFinancialFilter("receita")}
                >
                  Receitas
                </Button>
                <Button
                  variant={financialFilter === "despesa" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFinancialFilter("despesa")}
                >
                  Despesas
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredTransactions.map((transaction: any) => (
                <div key={transaction.id} className="flex justify-between items-center p-3 border rounded">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      {transaction.type === 'receita' ? 
                        <TrendingUp className="h-4 w-4 text-erp-success" /> : 
                        <TrendingDown className="h-4 w-4 text-erp-danger" />
                      }
                      <span className="font-medium">{transaction.description}</span>
                      <Badge variant="outline" className="text-xs">
                        {transaction.category}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {new Date(transaction.date).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <p className={`font-bold ${transaction.type === 'receita' ? 'text-erp-success' : 'text-erp-danger'}`}>
                      {transaction.type === 'receita' ? '+' : '-'}R$ {Number(transaction.amount || 0).toFixed(2)}
                    </p>
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => handleDeleteTransaction(transaction)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <FinancialModal 
          open={modalOpen}
          onOpenChange={setModalOpen}
          transaction={selectedTransaction}
          mode={modalMode}
        />

        <AlertDialogConfirm
          open={deleteDialogOpen}
          onOpenChange={setDeleteDialogOpen}
          onConfirm={confirmDeleteTransaction}
          title="Excluir Transação"
          description={`Tem certeza que deseja excluir a transação "${transactionToDelete?.description}"? Esta ação não pode ser desfeita.`}
        />
      </div>
    </Layout>
  );
};

export default Financeiro;