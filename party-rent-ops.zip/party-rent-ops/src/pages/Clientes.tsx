import React, { useState, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, Phone, Mail, MapPin, FileText, DollarSign, Plus, Search, Trash2 } from "lucide-react";
import { ClientModal } from "@/components/modals/ClientModal";
import { Client } from "@/types/erp";
import { useERP } from "@/context/ERPApiContext";
import { AlertDialogConfirm } from "@/components/ui/alert-dialog-confirm";

const Clientes = () => {
  const { clients, orders, getClients, getOrders, deleteClient } = useERP();
  const [searchTerm, setSearchTerm] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | undefined>();
  const [modalMode, setModalMode] = useState<"create" | "edit" | "view">("create");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [clientToDelete, setClientToDelete] = useState<Client | null>(null);

  useEffect(() => {
    getClients();
    getOrders();
  }, [getClients, getOrders]);

  const openModal = (mode: "create" | "edit" | "view", client?: Client) => {
    setModalMode(mode);
    setSelectedClient(client);
    setModalOpen(true);
  };

  const handleDeleteClient = (client: Client) => {
    setClientToDelete(client);
    setDeleteDialogOpen(true);
  };

  const confirmDeleteClient = async () => {
    if (clientToDelete) {
      try {
        await deleteClient(clientToDelete.id);
        setDeleteDialogOpen(false);
        setClientToDelete(null);
      } catch (error) {
        console.error('Erro ao excluir cliente:', error);
      }
    }
  };
  
  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.document.includes(searchTerm)
  );

  const getClientStats = (clientId: string) => {
    const clientOS = orders.filter(os => os.client_id === clientId);
    const totalValue = clientOS.reduce((acc, os) => acc + os.total_amount, 0);
    const activeOS = clientOS.filter(os => os.status === 'em_andamento' || os.status === 'confirmado').length;
    
    return {
      totalOrders: clientOS.length,
      totalValue,
      activeOrders: activeOS,
      lastOrder: clientOS[0]?.created_at ? new Date(clientOS[0].created_at).toLocaleDateString('pt-BR') : 'Nunca',
    };
  };

  return (
    <Layout>
      <div className="p-6 space-y-6 bg-background min-h-screen">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Clientes</h1>
            <p className="text-muted-foreground">Gerencie seus clientes e histórico de locações</p>
          </div>
          <Button className="bg-erp-primary hover:bg-erp-primary-light text-white" onClick={() => openModal("create")}>
            <Plus className="h-4 w-4 mr-2" />
            Novo Cliente
          </Button>
        </div>

        {/* Estatísticas Gerais */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-erp-primary/20 bg-gradient-to-br from-erp-primary/5 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total de Clientes</p>
                  <p className="text-2xl font-bold text-foreground">{clients.length}</p>
                </div>
                <Users className="h-8 w-8 text-erp-primary" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-erp-success/20 bg-gradient-to-br from-erp-success/5 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Clientes Ativos</p>
                  <p className="text-2xl font-bold text-foreground">
                    {clients.filter(client => 
                      orders.some(os => 
                        os.client_id === client.id && 
                        (os.status === 'em_andamento' || os.status === 'confirmado')
                      )
                    ).length}
                  </p>
                </div>
                <FileText className="h-8 w-8 text-erp-success" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-erp-secondary/20 bg-gradient-to-br from-erp-secondary/5 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Receita Total</p>
                  <p className="text-2xl font-bold text-foreground">
                    R$ {orders.reduce((acc, os) => acc + os.total_amount, 0).toFixed(2)}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-erp-secondary" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Ticket Médio</p>
                  <p className="text-2xl font-bold text-foreground">
                    R$ {orders.length > 0 
                      ? (orders.reduce((acc, os) => acc + os.total_amount, 0) / orders.length).toFixed(2)
                      : '0.00'
                    }
                  </p>
                </div>
                <Users className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Busca */}
        <Card>
          <CardContent className="p-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar clientes por nome, email ou documento..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </CardContent>
        </Card>

        {/* Lista de Clientes */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredClients.map((client) => {
            const stats = getClientStats(client.id);
            const isActive = stats.activeOrders > 0;
            
            return (
              <Card key={client.id} className={`hover:shadow-md transition-shadow ${
                isActive ? 'border-erp-success/30 bg-gradient-to-br from-erp-success/5 to-transparent' : ''
              }`}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Users className="h-5 w-5" />
                        {client.name}
                        {isActive && (
                          <Badge className="bg-erp-success text-white text-xs">
                            Ativo
                          </Badge>
                        )}
                      </CardTitle>
                      <div className="space-y-1 mt-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Mail className="h-4 w-4" />
                          {client.email}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-4 w-4" />
                          {client.phone}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <FileText className="h-4 w-4" />
                          {client.document}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-foreground">
                        {stats.totalOrders} OS
                      </p>
                      <p className="text-sm text-muted-foreground">
                        R$ {stats.totalValue.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        Endereço
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {client.address.street}, {client.address.number}
                        {client.address.complement && `, ${client.address.complement}`}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {client.address.city} - {client.address.state} | CEP: {client.address.zipCode}
                      </p>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 pt-3 border-t border-border">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">OS Ativas</p>
                        <p className="font-bold text-foreground">{stats.activeOrders}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Total OS</p>
                        <p className="font-bold text-foreground">{stats.totalOrders}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Última OS</p>
                        <p className="font-bold text-foreground text-xs">{stats.lastOrder}</p>
                      </div>
                    </div>
                    
                    <div className="flex justify-end gap-2 pt-3 border-t border-border">
                      <Button variant="outline" size="sm" onClick={() => openModal("view", client)}>
                        Ver Histórico
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => openModal("edit", client)}>
                        Editar
                      </Button>
                      <Button 
                        variant="destructive" 
                        size="sm"
                        onClick={() => handleDeleteClient(client)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <Button size="sm" className="bg-erp-primary hover:bg-erp-primary-light">
                        Nova OS
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Sem resultados */}
        {filteredClients.length === 0 && searchTerm && (
          <Card>
            <CardContent className="p-12 text-center">
              <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-medium text-foreground mb-2">Nenhum cliente encontrado</h3>
              <p className="text-muted-foreground">
                Tente buscar por um termo diferente ou cadastre um novo cliente.
              </p>
              <Button className="mt-4 bg-erp-primary hover:bg-erp-primary-light text-white">
                <Plus className="h-4 w-4 mr-2" />
                Cadastrar Cliente
              </Button>
            </CardContent>
          </Card>
        )}

        <ClientModal
          open={modalOpen}
          onOpenChange={setModalOpen}
          client={selectedClient}
          mode={modalMode}
        />

        <AlertDialogConfirm
          open={deleteDialogOpen}
          onOpenChange={setDeleteDialogOpen}
          onConfirm={confirmDeleteClient}
          title="Excluir Cliente"
          description={`Tem certeza que deseja excluir o cliente "${clientToDelete?.name}"? Esta ação não pode ser desfeita.`}
        />
      </div>
    </Layout>
  );
};

export default Clientes;