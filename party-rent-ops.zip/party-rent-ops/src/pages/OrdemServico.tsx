import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, FileText, Calendar, DollarSign, User, Clock, Trash2 } from "lucide-react";
import { OrderModal, PaymentModal } from "@/components/modals";
import { OrdemServico as OSType } from "@/types/erp";
import { useERP } from "@/context/ERPApiContext";
import { AlertDialogConfirm } from "@/components/ui/alert-dialog-confirm";

const OrdemServico = () => {
  const { orders, clients, products, deleteOrder, updateOrder } = useERP();
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<OSType | undefined>();
  const [orderModalMode, setOrderModalMode] = useState<"create" | "edit" | "view">("create");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState<OSType | null>(null);
  const [statusFilter, setStatusFilter] = useState<"all" | "orcamento" | "confirmado" | "finalizado">("all");

  const openOrderModal = (mode: "create" | "edit" | "view", order?: OSType) => {
    setOrderModalMode(mode);
    setSelectedOrder(order);
    setOrderModalOpen(true);
  };

  const openPaymentModal = (order: OSType) => {
    setSelectedOrder(order);
    setPaymentModalOpen(true);
  };

  const handleDeleteOrder = (order: OSType) => {
    setOrderToDelete(order);
    setDeleteDialogOpen(true);
  };

  const confirmDeleteOrder = async () => {
    if (orderToDelete) {
      try {
        await deleteOrder(orderToDelete.id);
        setDeleteDialogOpen(false);
        setOrderToDelete(null);
      } catch (error) {
        console.error('Erro ao excluir ordem de serviço:', error);
      }
    }
  };

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      await updateOrder(orderId, { status: newStatus as "orcamento" | "confirmado" | "em_andamento" | "finalizado" | "cancelado" });
    } catch (error) {
      console.error('Erro ao atualizar status:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'orcamento': return 'bg-gray-100 text-gray-800';
      case 'confirmado': return 'bg-blue-100 text-blue-800';
      case 'em_andamento': return 'bg-yellow-100 text-yellow-800';
      case 'finalizado': return 'bg-green-100 text-green-800';
      case 'cancelado': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'orcamento': return 'Orçamento';
      case 'confirmado': return 'Confirmado';
      case 'em_andamento': return 'Em Andamento';
      case 'finalizado': return 'Finalizado';
      case 'cancelado': return 'Cancelado';
      default: return status;
    }
  };

  const filteredOrders = orders.filter(order => statusFilter === "all" || order.status === statusFilter);

  return (
    <Layout>
      <div className="p-6 space-y-6 bg-background min-h-screen">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Ordens de Serviço</h1>
            <p className="text-muted-foreground">Gerencie suas ordens de serviço e locações</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant={statusFilter === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("all")}
            >
              Todas
            </Button>
            <Button
              variant={statusFilter === "orcamento" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("orcamento")}
            >
              Orçamento
            </Button>
            <Button
              variant={statusFilter === "confirmado" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("confirmado")}
            >
              Confirmado
            </Button>
            <Button
              variant={statusFilter === "finalizado" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("finalizado")}
            >
              Finalizado
            </Button>
            <Button 
              className="bg-erp-primary hover:bg-erp-primary-light text-white"
              onClick={() => openOrderModal("create")}
            >
              <Plus className="h-4 w-4 mr-2" />
              Nova OS
            </Button>
          </div>
        </div>

        {/* Estatísticas Rápidas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total de OS</p>
                  <p className="text-2xl font-bold text-foreground">{orders.length}</p>
                </div>
                <FileText className="h-8 w-8 text-erp-primary" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Em Andamento</p>
                  <p className="text-2xl font-bold text-foreground">
                    {orders.filter(os => os.status === 'em_andamento').length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-erp-warning" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Confirmadas</p>
                  <p className="text-2xl font-bold text-foreground">
                    {orders.filter(os => os.status === 'confirmado').length}
                  </p>
                </div>
                <Calendar className="h-8 w-8 text-erp-success" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Receita Total</p>
                  <p className="text-2xl font-bold text-foreground">
                    R$ {orders.reduce((acc, os) => acc + os.total_amount, 0).toFixed(2)}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-erp-primary" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Lista de Ordens de Serviço */}
        <div className="space-y-4">
          {filteredOrders.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">
                  {statusFilter === "all" 
                    ? "Nenhuma ordem de serviço encontrada" 
                    : `Nenhuma ordem de serviço com status "${getStatusText(statusFilter)}" encontrada`
                  }
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredOrders.map((os) => {
              const client = clients.find(c => c.id === os.client_id);
              return (
                <Card key={os.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <FileText className="h-5 w-5" />
                          OS #{os.order_number || os.id.slice(-6)}
                          <Select
                            value={os.status} 
                            onValueChange={(value) => handleStatusChange(os.id, value)}
                            disabled={os.status === 'finalizado'}
                          >
                            <SelectTrigger className="w-[140px] h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="orcamento">Orçamento</SelectItem>
                              <SelectItem value="confirmado">Confirmado</SelectItem>
                              <SelectItem value="em_andamento">Em Andamento</SelectItem>
                              <SelectItem value="finalizado">Finalizado</SelectItem>
                              <SelectItem value="cancelado">Cancelado</SelectItem>
                            </SelectContent>
                          </Select>
                        </CardTitle>
                        <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <User className="h-4 w-4" />
                            {client?.name}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {os.start_date} até {os.end_date}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-foreground">
                          R$ {os.total_amount.toFixed(2)}
                        </p>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>Sinal: R$ {os.signal_amount.toFixed(2)}</p>
                          <p>Pago: R$ {(os.total_amount - (os.remaining_amount || 0)).toFixed(2)}</p>
                          {os.remaining_amount > 0 && (
                            <p className="text-red-600 font-medium">
                              Pendente: R$ {os.remaining_amount.toFixed(2)}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-medium mb-2">Produtos:</h4>
                        <div className="space-y-2">
                          {os.products.map((item, index) => {
                            const product = products.find(p => p.id === item.product_id);
                            return (
                              <div key={index} className="flex justify-between items-center p-2 bg-secondary/30 rounded">
                                <div>
                                  <span className="font-medium">{product?.name}</span>
                                  <span className="text-sm text-muted-foreground ml-2">
                                    Qtd: {item.quantity} | {item.days} dias
                                  </span>
                                </div>
                                <span className="font-medium">R$ {item.total.toFixed(2)}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      
                      {os.delivery_address && (
                        <div>
                          <h4 className="font-medium mb-1">Endereço de Entrega:</h4>
                          <p className="text-sm text-muted-foreground">{os.delivery_address}</p>
                        </div>
                      )}
                      
                      {os.notes && (
                        <div>
                          <h4 className="font-medium mb-1">Observações:</h4>
                          <p className="text-sm text-muted-foreground">{os.notes}</p>
                        </div>
                      )}
                      
                      <div className="flex justify-end gap-2 pt-3 border-t">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => openOrderModal("view", os)}
                        >
                          Visualizar
                        </Button>
                        {os.status !== 'finalizado' && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => openOrderModal("edit", os)}
                          >
                            Editar
                          </Button>
                        )}
                        {os.status !== 'finalizado' && (
                          <Button 
                            size="sm" 
                            className="bg-erp-primary hover:bg-erp-primary-light"
                            onClick={() => openPaymentModal(os)}
                          >
                            Gerenciar Pagamentos
                          </Button>
                        )}
                        {os.status !== 'finalizado' && (
                          <Button 
                            variant="destructive" 
                            size="sm"
                            onClick={() => handleDeleteOrder(os)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        <OrderModal
          open={orderModalOpen}
          onOpenChange={setOrderModalOpen}
          order={selectedOrder}
          mode={orderModalMode}
        />

        <PaymentModal
          open={paymentModalOpen}
          onOpenChange={setPaymentModalOpen}
          order={selectedOrder}
          mode="create"
        />

        <AlertDialogConfirm
          open={deleteDialogOpen}
          onOpenChange={setDeleteDialogOpen}
          onConfirm={confirmDeleteOrder}
          title="Excluir Ordem de Serviço"
          description={`Tem certeza que deseja excluir a OS #${orderToDelete?.order_number || orderToDelete?.id?.slice(-6)}? Esta ação não pode ser desfeita.`}
        />
      </div>
    </Layout>
  );
};

export default OrdemServico;