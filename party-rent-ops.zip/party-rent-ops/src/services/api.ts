// Serviço de API para comunicação com o backend
const API_BASE_URL = 'http://localhost:3001/api';

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

async function apiRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const config: RequestInit = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  };

  try {
    const response = await fetch(url, config);
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
      throw new ApiError(response.status, errorData.error || `HTTP ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    
    // Erro de rede ou outros
    console.error('Erro na requisição API:', error);
    throw new ApiError(0, 'Erro de conexão com o servidor');
  }
}

// Products API
export const productsApi = {
  getAll: (params?: { category?: string; status?: string; search?: string }) => {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.set('category', params.category);
    if (params?.status) searchParams.set('status', params.status);
    if (params?.search) searchParams.set('search', params.search);
    
    const query = searchParams.toString();
    return apiRequest<any[]>(`/products${query ? `?${query}` : ''}`);
  },

  getById: (id: string) => apiRequest<any>(`/products/${id}`),

  create: (data: FormData) => {
    return fetch(`${API_BASE_URL}/products`, {
      method: 'POST',
      body: data, // FormData para upload de imagens
    }).then(async (response) => {
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
        throw new ApiError(response.status, errorData.error);
      }
      return response.json();
    });
  },

  update: (id: string, data: FormData) => {
    return fetch(`${API_BASE_URL}/products/${id}`, {
      method: 'PUT',
      body: data,
    }).then(async (response) => {
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
        throw new ApiError(response.status, errorData.error);
      }
      return response.json();
    });
  },

  delete: (id: string) => apiRequest(`/products/${id}`, { method: 'DELETE' }),

  getCategories: () => apiRequest<string[]>('/products/meta/categories'),
};

// Clients API
export const clientsApi = {
  getAll: (search?: string) => {
    const query = search ? `?search=${encodeURIComponent(search)}` : '';
    return apiRequest<any[]>(`/clients${query}`);
  },

  getById: (id: string) => apiRequest<any>(`/clients/${id}`),

  create: (data: any) => apiRequest<any>('/clients', {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  update: (id: string, data: any) => apiRequest<any>(`/clients/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),

  delete: (id: string) => apiRequest(`/clients/${id}`, { method: 'DELETE' }),
};

// Orders API
export const ordersApi = {
  getAll: (params?: { status?: string; client_id?: string; search?: string }) => {
    const searchParams = new URLSearchParams();
    if (params?.status) searchParams.set('status', params.status);
    if (params?.client_id) searchParams.set('client_id', params.client_id);
    if (params?.search) searchParams.set('search', params.search);
    
    const query = searchParams.toString();
    return apiRequest<any[]>(`/orders${query ? `?${query}` : ''}`);
  },

  getById: (id: string) => apiRequest<any>(`/orders/${id}`),

  create: (data: any) => apiRequest<any>('/orders', {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  update: (id: string, data: any) => apiRequest<any>(`/orders/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),

  delete: (id: string) => apiRequest(`/orders/${id}`, { method: 'DELETE' }),
};

// Dashboard API
export const dashboardApi = {
  getMetrics: () => apiRequest<any>('/dashboard/metrics'),
  getChartData: (period?: string) => {
    const query = period ? `?period=${period}` : '';
    return apiRequest<any[]>(`/dashboard/chart-data${query}`);
  },
  getPendingPayments: () => apiRequest<any[]>('/dashboard/pending-payments'),
  getRecentOrders: () => apiRequest<any[]>('/dashboard/recent-orders'),
};

// Payments API
export const paymentsApi = {
  getByOrderId: (orderId: string) => apiRequest<any[]>(`/payments?order_id=${orderId}`),
  
  create: (data: any) => apiRequest<any>('/payments', {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  update: (id: string, data: any) => apiRequest<any>(`/payments/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),

  markAsPaid: (id: string) => apiRequest<any>(`/payments/${id}/mark-paid`, {
    method: 'POST',
  }),

  delete: (id: string) => apiRequest(`/payments/${id}`, { method: 'DELETE' }),
};

// Financial API
export const financialApi = {
  getTransactions: (params?: { type?: string; period?: string }) => {
    const searchParams = new URLSearchParams();
    if (params?.type) searchParams.set('type', params.type);
    if (params?.period) searchParams.set('period', params.period);
    
    const query = searchParams.toString();
    return apiRequest<any[]>(`/financial/transactions${query ? `?${query}` : ''}`);
  },

  createTransaction: (data: any) => apiRequest<any>('/financial/transactions', {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  deleteTransaction: (id: string) => apiRequest(`/financial/transactions/${id}`, { method: 'DELETE' }),

  getReports: (params?: { startDate?: string; endDate?: string }) => {
    const searchParams = new URLSearchParams();
    if (params?.startDate) searchParams.set('startDate', params.startDate);
    if (params?.endDate) searchParams.set('endDate', params.endDate);
    
    const query = searchParams.toString();
    return apiRequest<any>(`/financial/reports${query ? `?${query}` : ''}`);
  },
};

// Agenda API
export const agendaApi = {
  getEvents: (params?: { date?: string; type?: string }) => {
    const searchParams = new URLSearchParams();
    if (params?.date) searchParams.set('date', params.date);
    if (params?.type) searchParams.set('type', params.type);
    
    const query = searchParams.toString();
    return apiRequest<any[]>(`/agenda/events${query ? `?${query}` : ''}`);
  },

  createEvent: (data: any) => apiRequest<any>('/agenda/events', {
    method: 'POST',
    body: JSON.stringify(data),
  }),

  updateEvent: (id: string, data: any) => apiRequest<any>(`/agenda/events/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),

  deleteEvent: (id: string) => apiRequest(`/agenda/events/${id}`, { method: 'DELETE' }),
};

export { ApiError };