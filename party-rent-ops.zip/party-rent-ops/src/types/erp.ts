// Tipos do sistema ERP - Preparados para integração PostgreSQL

export interface Product {
  id: string;
  name: string;
  category: string;
  quantity: number;
  available: number;
  rentPrice: number;
  status: 'available' | 'low_stock' | 'out_of_stock';
  images?: string[];
  description?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  document: string; // CPF/CNPJ
  address: {
    street: string;
    number: string;
    complement?: string;
    city: string;
    state: string;
    zipCode: string;
  };
  created_at: string;
  updated_at: string;
}

export interface OrdemServico {
  id: string;
  order_number?: string;
  client_id: string;
  client?: Client;
  products: {
    product_id: string;
    product?: Product;
    quantity: number;
    days: number;
    unit_price: number;
    total: number;
  }[];
  start_date: string;
  end_date: string;
  total_amount: number;
  signal_amount: number;
  remaining_amount: number;
  discount_amount?: number;
  status: 'orcamento' | 'confirmado' | 'em_andamento' | 'finalizado' | 'cancelado';
  delivery_address?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Payment {
  id: string;
  os_id: string;
  amount: number;
  type: 'sinal' | 'final' | 'parcial';
  method: 'dinheiro' | 'pix' | 'cartao_credito' | 'cartao_debito' | 'transferencia';
  status: 'pendente' | 'pago' | 'vencido';
  due_date: string;
  paid_date?: string;
  created_at: string;
}

export interface AgendaEvent {
  id: string;
  os_id: string;
  os?: OrdemServico;
  type: 'entrega' | 'retirada' | 'locacao_ativa';
  date: string;
  time?: string;
  title: string;
  description?: string;
  status: 'agendado' | 'realizado' | 'cancelado';
}

export interface FinancialTransaction {
  id: string;
  type: 'receita' | 'despesa';
  category: string;
  amount: number;
  description: string;
  date: string;
  os_id?: string;
  payment_id?: string;
  created_at: string;
}

export interface DashboardMetrics {
  monthlyRevenue: number;
  monthlyExpenses: number;
  productsInStock: number;
  pendingPayments: number;
  activeOrders: number;
  availableProducts: number;
}