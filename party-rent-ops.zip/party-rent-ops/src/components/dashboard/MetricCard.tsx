import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: "success" | "danger" | "warning" | "default";
}

export function MetricCard({ title, value, icon: Icon, trend, variant = "default" }: MetricCardProps) {
  const variants = {
    success: "border-erp-success/20 bg-gradient-to-br from-erp-success/5 to-transparent",
    danger: "border-erp-danger/20 bg-gradient-to-br from-erp-danger/5 to-transparent",
    warning: "border-erp-warning/20 bg-gradient-to-br from-erp-warning/5 to-transparent",
    default: "border-border bg-card",
  };

  const iconColors = {
    success: "text-erp-success",
    danger: "text-erp-danger",
    warning: "text-erp-warning",
    default: "text-erp-primary",
  };

  return (
    <Card className={cn("p-6 transition-all hover:shadow-md border-border bg-card", variants[variant])}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold text-foreground">{value}</p>
          {trend && (
            <p className={cn("text-xs mt-1", trend.isPositive ? "text-erp-success" : "text-erp-danger")}>
              {trend.isPositive ? "+" : ""}{trend.value}% vs mês anterior
            </p>
          )}
        </div>
        <div className={cn("p-3 rounded-full bg-secondary/50", iconColors[variant])}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
    </Card>
  );
}