import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, DollarSign } from "lucide-react";
import { useERP } from "@/context/ERPApiContext";
import { useState, useEffect } from "react";

export const PendingPayments = () => {
  const { orders, clients } = useERP();
  const [loading, setLoading] = useState(false);

  // Calcular pagamentos pendentes baseado no remaining_amount das OS
  const pendingPayments = orders
    .filter(order => (order.remaining_amount || 0) > 0)
    .map(order => {
      const client = clients.find(c => c.id === order.client_id);
      return {
        id: order.id,
        order_number: order.order_number || order.id.slice(-6),
        client_name: client?.name || 'Cliente não encontrado',
        amount: order.remaining_amount || 0,
        due_date: order.end_date || new Date().toISOString(),
        order_id: order.id
      };
    })
    .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Pagamentos Pendentes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Pagamentos Pendentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {pendingPayments.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <DollarSign className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>Nenhum pagamento pendente</p>
            </div>
          ) : (
            pendingPayments.slice(0, 5).map((payment) => (
              <div key={payment.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{payment.client_name}</span>
                    <Badge variant="outline" className="text-xs">
                      OS #{payment.order_number}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Vencimento: {new Date(payment.due_date).toLocaleDateString('pt-BR')}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold">R$ {Number(payment.amount).toFixed(2)}</p>
                  <Badge 
                    variant={
                      new Date(payment.due_date) < new Date() ? "destructive" : "secondary"
                    }
                    className="text-xs"
                  >
                    {new Date(payment.due_date) < new Date() ? "Vencido" : "Pendente"}
                  </Badge>
                </div>
              </div>
            ))
          )}
          
          {pendingPayments.length > 5 && (
            <Button variant="outline" className="w-full" size="sm">
              Ver todos ({pendingPayments.length})
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};