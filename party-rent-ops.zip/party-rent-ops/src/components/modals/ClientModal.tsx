import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { toast } from "@/hooks/use-toast";
import { Client } from "@/types/erp";
import { useERP } from "@/context/ERPApiContext";

const clientSchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  email: z.string().email("Email inválido"),
  phone: z.string().min(1, "Telefone é obrigatório"),
  document: z.string().min(1, "CPF/CNPJ é obrigatório"),
  address: z.object({
    street: z.string().min(1, "Rua é obrigatória"),
    number: z.string().min(1, "Número é obrigatório"),
    complement: z.string().optional(),
    city: z.string().min(1, "Cidade é obrigatória"),
    state: z.string().min(1, "Estado é obrigatório"),
    zipCode: z.string().min(1, "CEP é obrigatório"),
  }),
});

type ClientFormData = z.infer<typeof clientSchema>;

interface ClientModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  client?: Client;
  mode: "create" | "edit" | "view";
}

export function ClientModal({ open, onOpenChange, client, mode }: ClientModalProps) {
  const { createClient, updateClient } = useERP();
  const form = useForm<ClientFormData>({
    resolver: zodResolver(clientSchema),
    defaultValues: {
      name: client?.name || "",
      email: client?.email || "",
      phone: client?.phone || "",
      document: client?.document || "",
      address: {
        street: client?.address?.street || "",
        number: client?.address?.number || "",
        complement: client?.address?.complement || "",
        city: client?.address?.city || "",
        state: client?.address?.state || "",
        zipCode: client?.address?.zipCode || "",
      },
    },
  });

  const isViewMode = mode === "view";
  const isEditMode = mode === "edit";
  const isCreateMode = mode === "create";

  const onSubmit = async (data: ClientFormData) => {
    try {
      if (isCreateMode) {
        const newClient: Partial<Client> = {
          name: data.name,
          email: data.email,
          phone: data.phone,
          document: data.document,
          address: {
            street: data.address.street,
            number: data.address.number,
            complement: data.address.complement,
            city: data.address.city,
            state: data.address.state,
            zipCode: data.address.zipCode,
          },
        };
        await createClient(newClient);
      } else if (isEditMode && client) {
        const updatedClient: Partial<Client> = {
          name: data.name,
          email: data.email,
          phone: data.phone,
          document: data.document,
          address: {
            street: data.address.street,
            number: data.address.number,
            complement: data.address.complement,
            city: data.address.city,
            state: data.address.state,
            zipCode: data.address.zipCode,
          },
        };
        await updateClient(client.id, updatedClient);
      }
      
      onOpenChange(false);
    } catch (error) {
      // Error handling is done in the context
      console.error('Erro ao salvar cliente:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isCreateMode && "Novo Cliente"}
            {isEditMode && "Editar Cliente"} 
            {isViewMode && "Visualizar Cliente"}
          </DialogTitle>
        </DialogHeader>

        {isViewMode && client ? (
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold">{client.name}</h3>
              <p className="text-muted-foreground">{client.email}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-medium">Telefone</Label>
                <p className="text-muted-foreground">{client.phone}</p>
              </div>
              <div>
                <Label className="font-medium">CPF/CNPJ</Label>
                <p className="text-muted-foreground">{client.document}</p>
              </div>
            </div>

            <div>
              <Label className="font-medium">Endereço</Label>
              <div className="mt-2 text-muted-foreground">
                <p>{client.address.street}, {client.address.number}</p>
                {client.address.complement && <p>{client.address.complement}</p>}
                <p>{client.address.city} - {client.address.state}</p>
                <p>CEP: {client.address.zipCode}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <Label className="font-medium">Criado em</Label>
                <p className="text-muted-foreground">
                  {new Date(client.created_at).toLocaleDateString('pt-BR')}
                </p>
              </div>
              <div>
                <Label className="font-medium">Atualizado em</Label>
                <p className="text-muted-foreground">
                  {new Date(client.updated_at).toLocaleDateString('pt-BR')}
                </p>
              </div>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isViewMode} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} disabled={isViewMode} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefone</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isViewMode} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="document"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CPF/CNPJ</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isViewMode} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4">
                <Label className="text-base font-semibold">Endereço</Label>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-2">
                    <FormField
                      control={form.control}
                      name="address.street"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Rua</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isViewMode} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="address.number"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Número</FormLabel>
                        <FormControl>
                          <Input {...field} disabled={isViewMode} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="address.complement"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Complemento</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isViewMode} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="address.city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cidade</FormLabel>
                        <FormControl>
                          <Input {...field} disabled={isViewMode} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="address.state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Estado</FormLabel>
                        <FormControl>
                          <Input {...field} disabled={isViewMode} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="address.zipCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>CEP</FormLabel>
                        <FormControl>
                          <Input {...field} disabled={isViewMode} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {isCreateMode ? "Criar Cliente" : "Salvar Alterações"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}