import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CalendarIcon, CreditCard, Banknote, Smartphone } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { OrdemServico, Payment } from "@/types/erp";
import { useERP } from "@/context/ERPApiContext";

const paymentSchema = z.object({
  amount: z.number().min(0.01, "Valor deve ser maior que zero"),
  type: z.enum(["sinal", "final", "parcial"], {
    required_error: "Tipo de pagamento é obrigatório",
  }),
  method: z.enum(["dinheiro", "pix", "cartao_credito", "cartao_debito", "transferencia"], {
    required_error: "Método de pagamento é obrigatório",
  }),
  due_date: z.date({ required_error: "Data de vencimento é obrigatória" }),
  paid_date: z.date().optional(),
  status: z.enum(["pendente", "pago", "vencido"]).default("pendente"),
});

type PaymentFormData = z.infer<typeof paymentSchema>;

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order?: OrdemServico;
  payment?: Payment;
  mode: "create" | "edit" | "pay";
}

export function PaymentModal({ open, onOpenChange, order, payment, mode }: PaymentModalProps) {
  const { markPaymentAsPaid, createPayment } = useERP();
  
  const form = useForm<PaymentFormData>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      amount: payment?.amount || (mode === "create" && order ? order.remaining_amount : 0),
      type: payment?.type || "final",
      method: payment?.method || "dinheiro",
      due_date: payment ? new Date(payment.due_date) : new Date(),
      paid_date: payment?.paid_date ? new Date(payment.paid_date) : undefined,
      status: payment?.status || "pendente",
    },
  });

  const isPayMode = mode === "pay";
  const isCreateMode = mode === "create";
  const isEditMode = mode === "edit";

  const getPaymentTypeIcon = (method: string) => {
    const icons = {
      dinheiro: <Banknote className="h-4 w-4" />,
      pix: <Smartphone className="h-4 w-4" />,
      cartao_credito: <CreditCard className="h-4 w-4" />,
      cartao_debito: <CreditCard className="h-4 w-4" />,
      transferencia: <Smartphone className="h-4 w-4" />,
    };
    return icons[method as keyof typeof icons] || <CreditCard className="h-4 w-4" />;
  };

  const getPaymentTypeText = (method: string) => {
    const texts = {
      dinheiro: "Dinheiro",
      pix: "PIX",
      cartao_credito: "Cartão de Crédito",
      cartao_debito: "Cartão de Débito",
      transferencia: "Transferência",
    };
    return texts[method as keyof typeof texts] || method;
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      pendente: "bg-erp-warning text-white",
      pago: "bg-erp-success text-white",
      vencido: "bg-erp-danger text-white",
    };
    
    const statusTexts = {
      pendente: "Pendente",
      pago: "Pago",
      vencido: "Vencido",
    };

    return (
      <Badge className={statusColors[status as keyof typeof statusColors]}>
        {statusTexts[status as keyof typeof statusTexts]}
      </Badge>
    );
  };

  const onSubmit = async (data: PaymentFormData) => {
    try {
      if (isPayMode && order) {
        // Usar a nova função para marcar pagamento como pago
        await markPaymentAsPaid(
          order.id, 
          data.amount, 
          `Pagamento OS #${order.order_number || order.id.slice(-6)} - ${getPaymentTypeText(data.method)}`
        );
        toast({
          title: "Pagamento confirmado!",
          description: `Pagamento de R$ ${data.amount.toFixed(2)} foi confirmado e registrado no financeiro.`,
        });
      } else if (isCreateMode && order) {
        // Validar valor para pagamentos parciais
        if (data.type === 'parcial' && data.amount > order.remaining_amount) {
          toast({
            title: "Erro",
            description: `Valor excede o pendente da OS: R$ ${order.remaining_amount.toFixed(2)}`,
            variant: "destructive",
          });
          return;
        }

        // Criar pagamento que automaticamente registra transação financeira se for parcial
        const paymentData = {
          order_id: order.id,
          os_id: order.id, // Para compatibilidade
          amount: data.amount,
          type: data.type,
          method: data.method,
          due_date: data.due_date.toISOString().split('T')[0],
        };

        await createPayment(paymentData);
        
        toast({
          title: "Pagamento criado!",
          description: data.type === 'parcial' 
            ? `Pagamento parcial de R$ ${data.amount.toFixed(2)} foi criado e contabilizado automaticamente!`
            : `Pagamento de R$ ${data.amount.toFixed(2)} foi criado com sucesso.`,
        });
      } else {
        // Editar pagamento normal
        console.log("Editando pagamento:", data);
        
        toast({
          title: "Pagamento atualizado!",
          description: `Pagamento de R$ ${data.amount.toFixed(2)} foi atualizado com sucesso.`,
        });
      }
      
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error?.message || "Erro ao processar pagamento",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {isCreateMode && "Novo Pagamento"}
            {isEditMode && "Editar Pagamento"}
            {isPayMode && "Confirmar Pagamento"}
          </DialogTitle>
          {order && (
            <div className="text-sm text-muted-foreground">
              OS #{order.id} - Cliente: {order.client?.name || 'Cliente não encontrado'}
            </div>
          )}
        </DialogHeader>

        {order && (
          <div className="mb-4 p-4 bg-muted rounded-lg">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <Label className="font-medium">Total da OS</Label>
                <p className="text-muted-foreground">R$ {order.total_amount.toFixed(2)}</p>
              </div>
              <div>
                <Label className="font-medium">Sinal Pago</Label>
                <p className="text-muted-foreground">R$ {order.signal_amount.toFixed(2)}</p>
              </div>
              <div>
                <Label className="font-medium">Restante</Label>
                <p className="text-lg font-bold text-erp-primary">R$ {order.remaining_amount.toFixed(2)}</p>
              </div>
              <div>
                <Label className="font-medium">Status</Label>
                {payment && getStatusBadge(payment.status)}
              </div>
            </div>
          </div>
        )}

        {!order ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">Selecione uma ordem de serviço para gerenciar pagamentos.</p>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Valor (R$)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        {...field}
                        onChange={e => field.onChange(Number(e.target.value))}
                        disabled={isPayMode}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isPayMode}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="sinal">Sinal</SelectItem>
                        <SelectItem value="final">Final</SelectItem>
                        <SelectItem value="parcial">Parcial</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="method"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Método de Pagamento</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="dinheiro">
                        <div className="flex items-center gap-2">
                          <Banknote className="h-4 w-4" />
                          Dinheiro
                        </div>
                      </SelectItem>
                      <SelectItem value="pix">
                        <div className="flex items-center gap-2">
                          <Smartphone className="h-4 w-4" />
                          PIX
                        </div>
                      </SelectItem>
                      <SelectItem value="cartao_credito">
                        <div className="flex items-center gap-2">
                          <CreditCard className="h-4 w-4" />
                          Cartão de Crédito
                        </div>
                      </SelectItem>
                      <SelectItem value="cartao_debito">
                        <div className="flex items-center gap-2">
                          <CreditCard className="h-4 w-4" />
                          Cartão de Débito
                        </div>
                      </SelectItem>
                      <SelectItem value="transferencia">
                        <div className="flex items-center gap-2">
                          <Smartphone className="h-4 w-4" />
                          Transferência
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="due_date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Data de Vencimento</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                          disabled={isPayMode}
                        >
                          {field.value ? (
                            format(field.value, "dd/MM/yyyy", { locale: ptBR })
                          ) : (
                            <span>Selecione uma data</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            {isPayMode && (
              <div className="p-4 bg-erp-success/10 border border-erp-success/20 rounded-lg">
                <div className="flex items-center gap-2 text-erp-success">
                  {getPaymentTypeIcon(form.watch("method"))}
                  <span className="font-medium">
                    Confirmando pagamento de R$ {form.watch("amount")?.toFixed(2)} via {getPaymentTypeText(form.watch("method"))}
                  </span>
                </div>
              </div>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button type="submit" className={isPayMode ? "bg-erp-success hover:bg-erp-success/90" : ""}>
                {isPayMode && "Confirmar Pagamento"}
                {isCreateMode && "Criar Pagamento"}
                {isEditMode && "Salvar Alterações"}
              </Button>
            </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}