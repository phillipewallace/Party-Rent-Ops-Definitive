import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CalendarIcon, TrendingUp, TrendingDown } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { FinancialTransaction } from "@/types/erp";
import { useERP } from "@/context/ERPApiContext";

const financialSchema = z.object({
  type: z.enum(["receita", "despesa"], {
    required_error: "Tipo é obrigatório",
  }),
  category: z.string().min(1, "Categoria é obrigatória"),
  amount: z.number().min(0.01, "Valor deve ser maior que zero"),
  description: z.string().min(1, "Descrição é obrigatória"),
  date: z.date({ required_error: "Data é obrigatória" }),
});

type FinancialFormData = z.infer<typeof financialSchema>;

interface FinancialModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  transaction?: FinancialTransaction;
  mode: "create" | "edit";
  defaultType?: "receita" | "despesa";
}

const receitaCategories = [
  "Locação de Equipamentos",
  "Serviços de Evento",
  "Taxa de Entrega",
  "Multas e Juros",
  "Outras Receitas"
];

const despesaCategories = [
  "Compra de Equipamentos",
  "Manutenção",
  "Combustível",
  "Salários",
  "Aluguel",
  "Energia Elétrica",
  "Internet/Telefone",
  "Marketing",
  "Impostos",
  "Outras Despesas"
];

export function FinancialModal({ 
  open, 
  onOpenChange, 
  transaction, 
  mode, 
  defaultType = "receita" 
}: FinancialModalProps) {
  const { createTransaction } = useERP();
  const form = useForm<FinancialFormData>({
    resolver: zodResolver(financialSchema),
    defaultValues: {
      type: transaction?.type || defaultType,
      category: transaction?.category || "",
      amount: transaction?.amount || 0,
      description: transaction?.description || "",
      date: transaction ? new Date(transaction.date) : new Date(),
    },
  });

  const isCreateMode = mode === "create";
  const selectedType = form.watch("type");
  const categories = selectedType === "receita" ? receitaCategories : despesaCategories;

  const onSubmit = async (data: FinancialFormData) => {
    try {
      const transactionData = {
        type: data.type,
        category: data.category,
        amount: data.amount,
        description: data.description,
        date: data.date.toISOString().split('T')[0],
      };

      await createTransaction(transactionData);
      onOpenChange(false);
    } catch (error) {
      // Error handling is done in the context
      console.error('Erro ao salvar transação:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {selectedType === "receita" ? (
              <TrendingUp className="h-5 w-5 text-erp-success" />
            ) : (
              <TrendingDown className="h-5 w-5 text-erp-danger" />
            )}
            {isCreateMode ? "Nova Transação" : "Editar Transação"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="receita">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-erp-success" />
                          Receita
                        </div>
                      </SelectItem>
                      <SelectItem value="despesa">
                        <div className="flex items-center gap-2">
                          <TrendingDown className="h-4 w-4 text-erp-danger" />
                          Despesa
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Categoria</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione uma categoria" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Valor (R$)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        {...field}
                        onChange={e => field.onChange(Number(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Data</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "dd/MM/yyyy", { locale: ptBR })
                          ) : (
                            <span>Selecione uma data</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field}
                      placeholder="Descreva a transação..."
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Preview */}
            <div className={cn(
              "p-4 rounded-lg border-2",
              selectedType === "receita" 
                ? "bg-erp-success/10 border-erp-success/20" 
                : "bg-erp-danger/10 border-erp-danger/20"
            )}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {selectedType === "receita" ? (
                    <TrendingUp className="h-4 w-4 text-erp-success" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-erp-danger" />
                  )}
                  <span className="font-medium">
                    {selectedType === "receita" ? "Receita" : "Despesa"}
                  </span>
                </div>
                <span className={cn(
                  "text-lg font-bold",
                  selectedType === "receita" ? "text-erp-success" : "text-erp-danger"
                )}>
                  R$ {form.watch("amount")?.toFixed(2) || "0,00"}
                </span>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button 
                type="submit"
                className={cn(
                  selectedType === "receita" 
                    ? "bg-erp-success hover:bg-erp-success/90" 
                    : "bg-erp-danger hover:bg-erp-danger/90"
                )}
              >
                {isCreateMode ? "Criar Transação" : "Salvar Alterações"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}