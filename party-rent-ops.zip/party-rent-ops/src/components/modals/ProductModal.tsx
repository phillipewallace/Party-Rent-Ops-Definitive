import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useERP } from "@/context/ERPApiContext";
import { Upload, X, ImageIcon, ZoomIn } from "lucide-react";
import { Product } from "@/types/erp";

const productSchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  category: z.string().min(1, "Categoria é obrigatória"),
  quantity: z.number().min(0, "Quantidade deve ser positiva"),
  available: z.number().min(0, "Quantidade disponível deve ser positiva"),
  rentPrice: z.number().min(0, "Preço deve ser positivo"),
  description: z.string().optional(),
});

type ProductFormData = z.infer<typeof productSchema>;

interface ProductModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product?: Product;
  mode: "create" | "edit" | "view";
}

export function ProductModal({ open, onOpenChange, product, mode }: ProductModalProps) {
  const { toast } = useToast();
  const { createProduct, updateProduct } = useERP();
  const [images, setImages] = useState<string[]>([]);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  
  const form = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      category: "",
      quantity: 0,
      available: 0,
      rentPrice: 0,
      description: "",
    },
  });

  // Reset form and images when product changes
  useEffect(() => {
    if (product) {
      form.reset({
        name: product.name,
        category: product.category,
        quantity: product.quantity,
        available: product.available,
        rentPrice: product.rentPrice,
        description: product.description || "",
      });
      setImages(product.images ? [...product.images] : []);
    } else {
      form.reset({
        name: "",
        category: "",
        quantity: 0,
        available: 0,
        rentPrice: 0,
        description: "",
      });
      setImages([]);
      setImageFiles([]);
    }
  }, [product, form]);

  const isViewMode = mode === "view";
  const isEditMode = mode === "edit";
  const isCreateMode = mode === "create";

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newFiles = Array.from(files);
      setImageFiles(prev => [...prev, ...newFiles]);
      
      const newImages: string[] = [];
      newFiles.forEach((file) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            newImages.push(e.target.result as string);
            if (newImages.length === newFiles.length) {
              setImages(prev => [...prev, ...newImages]);
            }
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
    setImageFiles(prev => prev.filter((_, i) => i !== index));
  };

  const onSubmit = async (data: ProductFormData) => {
    try {
      const formData = new FormData();
      formData.append('name', data.name);
      formData.append('category', data.category);
      formData.append('quantity', data.quantity.toString());
      formData.append('available', data.available.toString());
      formData.append('rent_price', data.rentPrice.toString());
      formData.append('description', data.description || '');

      // Adicionar imagens existentes se estiver editando (somente as que não foram removidas)
      const existingImages = images.filter(img => !img.startsWith('data:'));
      existingImages.forEach((img) => {
        formData.append(`existing_images`, img);
      });

      // Adicionar novas imagens
      imageFiles.forEach((file) => {
        formData.append('images', file);
      });

      if (mode === 'create') {
        await createProduct(formData);
      } else if (mode === 'edit' && product) {
        await updateProduct(product.id, formData);
      }

      onOpenChange(false);
    } catch (error) {
      // Erro já foi tratado no contexto
    }
  };

  const getStatusBadge = (product: Product) => {
    const statusColors = {
      available: "bg-erp-success text-white",
      low_stock: "bg-erp-warning text-white", 
      out_of_stock: "bg-erp-danger text-white"
    };
    
    const statusTexts = {
      available: "Disponível",
      low_stock: "Estoque Baixo",
      out_of_stock: "Indisponível"
    };

    return (
      <Badge className={statusColors[product.status]}>
        {statusTexts[product.status]}
      </Badge>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isCreateMode && "Novo Produto"}
            {isEditMode && "Editar Produto"} 
            {isViewMode && "Visualizar Produto"}
          </DialogTitle>
        </DialogHeader>

        {isViewMode && product ? (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold">{product.name}</h3>
              {getStatusBadge(product)}
            </div>

            {(product?.images && product.images.length > 0) && (
              <div className="grid grid-cols-3 gap-4">
                {product.images.map((image, index) => (
                  <div key={index} className="relative group cursor-pointer" onClick={() => {
                    setSelectedImageIndex(index);
                    setLightboxOpen(true);
                  }}>
                    <img
                      src={`http://localhost:3001${image}`}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-32 object-cover rounded-lg transition-all group-hover:brightness-75"
                      onError={(e) => {
                        console.error('Error loading image:', image);
                        e.currentTarget.src = '/placeholder.svg';
                      }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <ZoomIn className="h-8 w-8 text-white" />
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-medium">Categoria</Label>
                <p className="text-muted-foreground">{product.category}</p>
              </div>
              <div>
                <Label className="font-medium">Preço Diário</Label>
                <p className="text-muted-foreground">R$ {product.rentPrice.toFixed(2)}</p>
              </div>
              <div>
                <Label className="font-medium">Quantidade Total</Label>
                <p className="text-muted-foreground">{product.quantity}</p>
              </div>
              <div>
                <Label className="font-medium">Disponível</Label>
                <p className="text-muted-foreground">{product.available}</p>
              </div>
            </div>

            {product.description && (
              <div>
                <Label className="font-medium">Descrição</Label>
                <p className="text-muted-foreground mt-1">{product.description}</p>
              </div>
            )}
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isViewMode} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Categoria</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isViewMode}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione uma categoria" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="som">Som e Iluminação</SelectItem>
                          <SelectItem value="decoracao">Decoração</SelectItem>
                          <SelectItem value="mobiliario">Mobiliário</SelectItem>
                          <SelectItem value="estrutura">Estruturas</SelectItem>
                          <SelectItem value="buffet">Buffet</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantidade Total</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={e => field.onChange(Number(e.target.value))}
                          disabled={isViewMode}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="available"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Disponível</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={e => field.onChange(Number(e.target.value))}
                          disabled={isViewMode}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="rentPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preço Diário (R$)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          {...field} 
                          onChange={e => field.onChange(Number(e.target.value))}
                          disabled={isViewMode}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição</FormLabel>
                    <FormControl>
                      <Textarea {...field} disabled={isViewMode} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {!isViewMode && (
                <div>
                  <Label>Imagens</Label>
                  <div className="mt-2">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="image-upload"
                    />
                    <label
                      htmlFor="image-upload"
                      className="flex items-center justify-center w-full h-32 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-muted/50"
                    >
                      <div className="text-center">
                        <Upload className="mx-auto h-8 w-8 text-muted-foreground" />
                        <p className="mt-2 text-sm text-muted-foreground">
                          Clique para adicionar imagens
                        </p>
                      </div>
                    </label>
                  </div>

                  {images.length > 0 && (
                    <div className="grid grid-cols-4 gap-4 mt-4">
                      {images.map((image, index) => (
                        <div key={index} className="relative">
                          <img
                            src={image.startsWith('data:') ? image : `http://localhost:3001${image}`}
                            alt={`Preview ${index + 1}`}
                            className="w-full h-24 object-cover rounded-lg"
                            onError={(e) => {
                              console.error('Error loading image:', image);
                              e.currentTarget.src = '/placeholder.svg';
                            }}
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="sm"
                            className="absolute -top-2 -right-2 h-6 w-6 p-0"
                            onClick={() => removeImage(index)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {isCreateMode ? "Criar Produto" : "Salvar Alterações"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}

        {/* Lightbox Modal */}
        {product?.images && (
          <Dialog open={lightboxOpen} onOpenChange={setLightboxOpen}>
            <DialogContent className="max-w-4xl max-h-[90vh] p-0">
              <div className="relative">
                <img
                  src={`http://localhost:3001${product.images[selectedImageIndex]}`}
                  alt={`${product.name} ${selectedImageIndex + 1}`}
                  className="w-full h-auto max-h-[80vh] object-contain"
                  onError={(e) => {
                    e.currentTarget.src = '/placeholder.svg';
                  }}
                />
                <Button
                  variant="outline"
                  size="sm"
                  className="absolute top-4 right-4"
                  onClick={() => setLightboxOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
                {product.images.length > 1 && (
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                    {product.images.map((_, index) => (
                      <Button
                        key={index}
                        variant={index === selectedImageIndex ? "default" : "outline"}
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => setSelectedImageIndex(index)}
                      >
                        {index + 1}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        )}
      </DialogContent>
    </Dialog>
  );
}