import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CalendarIcon, Plus, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { OrdemServico, Client, Product } from "@/types/erp";
import { useERP } from "@/context/ERPApiContext";

const orderSchema = z.object({
  client_id: z.string().min(1, "Cliente é obrigatório"),
  start_date: z.date({ required_error: "Data de início é obrigatória" }),
  end_date: z.date({ required_error: "Data de fim é obrigatória" }),
  delivery_address: z.string().optional(),
  notes: z.string().optional(),
  signal_amount: z.number().min(0, "Valor do sinal deve ser positivo"),
  discount_amount: z.number().min(0, "Valor do desconto deve ser positivo").optional(),
});

type OrderFormData = z.infer<typeof orderSchema>;

interface ProductSelection {
  product_id: string;
  quantity: number;
  days: number;
  unit_price: number;
  total: number;
}

interface OrderModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order?: OrdemServico;
  mode: "create" | "edit" | "view";
}

export function OrderModal({ open, onOpenChange, order, mode }: OrderModalProps) {
  const { clients, products, createOrder, updateOrder } = useERP();
  const [selectedProducts, setSelectedProducts] = useState<ProductSelection[]>([]);

  const form = useForm<OrderFormData>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      client_id: "",
      start_date: undefined,
      end_date: undefined,
      delivery_address: "",
      notes: "",
      signal_amount: 0,
      discount_amount: 0,
    },
  });

  // Reset form and products when order changes or modal opens
  React.useEffect(() => {
    if (open) {
      if (order && (mode === 'edit' || mode === 'view')) {
        // Edit or view mode - populate with order data
        form.reset({
          client_id: order.client_id,
          start_date: new Date(order.start_date),
          end_date: new Date(order.end_date),
          delivery_address: order.delivery_address || "",
          notes: order.notes || "",
          signal_amount: order.signal_amount || 0,
          discount_amount: order.discount_amount || 0,
        });
        setSelectedProducts(order.products || []);
      } else {
        // Create mode - reset to empty
        form.reset({
          client_id: "",
          start_date: undefined,
          end_date: undefined,
          delivery_address: "",
          notes: "",
          signal_amount: 0,
          discount_amount: 0,
        });
        setSelectedProducts([]);
      }
    }
  }, [open, order, mode, form]);

  const isViewMode = mode === "view";
  const isEditMode = mode === "edit";
  const isCreateMode = mode === "create";

  const addProduct = () => {
    setSelectedProducts(prev => [
      ...prev,
      { product_id: "", quantity: 1, days: 1, unit_price: 0, total: 0 }
    ]);
  };

  const removeProduct = (index: number) => {
    setSelectedProducts(prev => prev.filter((_, i) => i !== index));
  };

  const updateProduct = (index: number, field: keyof ProductSelection, value: any) => {
    setSelectedProducts(prev => prev.map((item, i) => {
      if (i !== index) return item;
      
      const updated = { ...item, [field]: value };
      
      if (field === 'product_id') {
        const product = products.find(p => p.id === value);
        if (product) {
          updated.unit_price = product.rentPrice || 0;
        }
      }
      
      // Recalculate total
      updated.total = updated.quantity * updated.days * updated.unit_price;
      
      return updated;
    }));
  };

  const calculateTotal = () => {
    return selectedProducts.reduce((sum, item) => sum + item.total, 0);
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      orcamento: "bg-erp-warning text-white",
      confirmado: "bg-erp-primary text-white",
      em_andamento: "bg-erp-primary-light text-white",
      finalizado: "bg-erp-success text-white",
      cancelado: "bg-erp-danger text-white"
    };
    
    const statusTexts = {
      orcamento: "Orçamento",
      confirmado: "Confirmado",
      em_andamento: "Em Andamento",
      finalizado: "Finalizado",
      cancelado: "Cancelado"
    };

    return (
      <Badge className={statusColors[status as keyof typeof statusColors]}>
        {statusTexts[status as keyof typeof statusTexts]}
      </Badge>
    );
  };

  const onSubmit = async (data: OrderFormData) => {
    try {
      const subtotal = calculateTotal();
      const discountAmount = data.discount_amount || 0;
      const total = subtotal - discountAmount;
      const remaining = total - data.signal_amount;

      const orderData = {
        client_id: data.client_id,
        start_date: data.start_date.toISOString().split('T')[0],
        end_date: data.end_date.toISOString().split('T')[0],
        delivery_address: data.delivery_address,
        notes: data.notes,
        signal_amount: data.signal_amount,
        discount_amount: discountAmount,
        products: selectedProducts,
        total_amount: total,
        remaining_amount: remaining,
        status: order?.status || 'orcamento'
      };

      if (isCreateMode) {
        await createOrder(orderData);
      } else if (isEditMode && order) {
        await updateOrder(order.id, orderData);
      }
      
      onOpenChange(false);
    } catch (error) {
      // Error handling is done in the context
      console.error('Erro ao salvar ordem de serviço:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isCreateMode && "Nova Ordem de Serviço"}
            {isEditMode && "Editar Ordem de Serviço"}
            {isViewMode && "Visualizar Ordem de Serviço"}
            {isViewMode && order && getStatusBadge(order.status)}
          </DialogTitle>
        </DialogHeader>

        {isViewMode && order ? (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-medium">Cliente</Label>
                <p className="text-muted-foreground">{order.client?.name}</p>
              </div>
              <div>
                <Label className="font-medium">Total</Label>
                <p className="text-muted-foreground">R$ {(order.total_amount || 0).toFixed(2)}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-medium">Data de Início</Label>
                <p className="text-muted-foreground">
                  {format(new Date(order.start_date), "dd/MM/yyyy", { locale: ptBR })}
                </p>
              </div>
              <div>
                <Label className="font-medium">Data de Fim</Label>
                <p className="text-muted-foreground">
                  {format(new Date(order.end_date), "dd/MM/yyyy", { locale: ptBR })}
                </p>
              </div>
            </div>

            <div>
              <Label className="font-medium">Produtos</Label>
              <div className="mt-2 space-y-2">
                {order.products.map((item, index) => (
                  <div key={index} className="p-3 border rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{item.product?.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {item.quantity}x por {item.days} dias
                        </p>
                      </div>
                      <p className="font-medium">R$ {(item.total || 0).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {order.delivery_address && (
              <div>
                <Label className="font-medium">Endereço de Entrega</Label>
                <p className="text-muted-foreground">{order.delivery_address}</p>
              </div>
            )}

            {order.notes && (
              <div>
                <Label className="font-medium">Observações</Label>
                <p className="text-muted-foreground">{order.notes}</p>
              </div>
            )}

            <div className="grid grid-cols-4 gap-4 p-4 bg-muted rounded-lg">
              <div>
                <Label className="font-medium">Subtotal</Label>
                <p className="text-muted-foreground">R$ {(selectedProducts.reduce((sum, item) => sum + item.total, 0) || 0).toFixed(2)}</p>
              </div>
              <div>
                <Label className="font-medium">Desconto</Label>
                <p className="text-muted-foreground">R$ {(order.discount_amount || 0).toFixed(2)}</p>
              </div>
              <div>
                <Label className="font-medium">Sinal</Label>
                <p className="text-muted-foreground">R$ {(order.signal_amount || 0).toFixed(2)}</p>
              </div>
              <div>
                <Label className="font-medium">Restante</Label>
                <p className="text-muted-foreground">R$ {(order.remaining_amount || 0).toFixed(2)}</p>
              </div>
              <div className="col-span-4 pt-2 border-t">
                <Label className="font-medium">Total</Label>
                <p className="text-xl font-bold text-erp-primary">R$ {(order.total_amount || 0).toFixed(2)}</p>
              </div>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="client_id"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cliente</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isViewMode}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione um cliente" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {clients.map((client) => (
                            <SelectItem key={client.id} value={client.id}>
                              {client.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="signal_amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Valor do Sinal (R$)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          {...field}
                          onChange={e => field.onChange(Number(e.target.value))}
                          disabled={isViewMode}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="signal_amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Valor do Sinal (R$)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          {...field}
                          onChange={e => field.onChange(Number(e.target.value))}
                          disabled={isViewMode}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="discount_amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Desconto (R$)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          {...field}
                          onChange={e => field.onChange(Number(e.target.value) || 0)}
                          disabled={isViewMode}
                          placeholder="0.00"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex flex-col">
                  <Label className="mb-2">Total Final</Label>
                  <div className="p-2 bg-muted rounded-md text-lg font-bold text-erp-primary">
                    R$ {((calculateTotal() - (form.watch("discount_amount") || 0))).toFixed(2)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="start_date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Data de Início</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                              disabled={isViewMode}
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy", { locale: ptBR })
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date()}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="end_date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Data de Fim</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                              disabled={isViewMode}
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy", { locale: ptBR })
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date()}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                 />

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="discount_amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Desconto (R$)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          {...field}
                          onChange={e => field.onChange(Number(e.target.value) || 0)}
                          disabled={isViewMode}
                          placeholder="0.00"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex flex-col">
                  <Label className="mb-2">Subtotal</Label>
                  <div className="p-2 bg-muted rounded-md text-sm text-muted-foreground">
                    R$ {calculateTotal().toFixed(2)}
                  </div>
                </div>

                <div className="flex flex-col">
                  <Label className="mb-2">Total com Desconto</Label>
                  <div className="p-2 bg-muted rounded-md text-lg font-bold text-erp-primary">
                    R$ {((calculateTotal() - (form.watch("discount_amount") || 0))).toFixed(2)}
                  </div>
                </div>
              </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-base font-semibold">Produtos</Label>
                  {!isViewMode && (
                    <Button type="button" variant="outline" size="sm" onClick={addProduct}>
                      <Plus className="h-4 w-4 mr-2" />
                      Adicionar Produto
                    </Button>
                  )}
                </div>

                <div className="space-y-4">
                  {selectedProducts.map((item, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="grid grid-cols-6 gap-4 items-end">
                        <div className="col-span-2">
                          <Label>Produto</Label>
                          <Select
                            value={item.product_id}
                            onValueChange={(value) => updateProduct(index, 'product_id', value)}
                            disabled={isViewMode}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione um produto" />
                            </SelectTrigger>
                            <SelectContent>
                              {products.map((product) => (
                                <SelectItem key={product.id} value={product.id}>
                                  {product.name} - R$ {(product.rentPrice || 0).toFixed(2)}/dia
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label>Qtd</Label>
                          <Input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateProduct(index, 'quantity', Number(e.target.value))}
                            disabled={isViewMode}
                          />
                        </div>

                        <div>
                          <Label>Dias</Label>
                          <Input
                            type="number"
                            min="1"
                            value={item.days}
                            onChange={(e) => updateProduct(index, 'days', Number(e.target.value))}
                            disabled={isViewMode}
                          />
                        </div>

                        <div>
                          <Label>Total</Label>
                          <p className="p-2 text-right font-medium">
                            R$ {(item.total || 0).toFixed(2)}
                          </p>
                        </div>

                        {!isViewMode && (
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeProduct(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {selectedProducts.length > 0 && (
                  <div className="mt-4 p-4 bg-muted rounded-lg">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Total Geral:</span>
                      <span className="text-xl font-bold text-erp-primary">
                        R$ {calculateTotal().toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <FormField
                control={form.control}
                name="delivery_address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Endereço de Entrega</FormLabel>
                    <FormControl>
                      <Input {...field} disabled={isViewMode} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Observações</FormLabel>
                    <FormControl>
                      <Textarea {...field} disabled={isViewMode} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {isCreateMode ? "Criar OS" : "Salvar Alterações"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}