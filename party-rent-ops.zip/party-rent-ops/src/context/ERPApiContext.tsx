import React, { createContext, useContext, useState, useCallback } from 'react';
import { Product, Client, OrdemServico, DashboardMetrics, FinancialTransaction } from '../types/erp';
import { 
  productsApi, 
  clientsApi, 
  ordersApi, 
  dashboardApi,
  paymentsApi,
  financialApi,
  agendaApi 
} from '../services/api';
import { useToast } from '@/hooks/use-toast';

interface ERPContextType {
  // Products
  products: Product[];
  loadingProducts: boolean;
  getProducts: () => Promise<void>;
  createProduct: (data: FormData) => Promise<void>;
  updateProduct: (id: string, data: FormData) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;

  // Clients
  clients: Client[];
  loadingClients: boolean;
  getClients: () => Promise<void>;
  createClient: (data: Partial<Client>) => Promise<void>;
  updateClient: (id: string, data: Partial<Client>) => Promise<void>;
  deleteClient: (id: string) => Promise<void>;

  // Orders
  orders: OrdemServico[];
  loadingOrders: boolean;
  getOrders: () => Promise<void>;
  createOrder: (data: Partial<OrdemServico>) => Promise<void>;
  updateOrder: (id: string, data: Partial<OrdemServico>) => Promise<void>;
  deleteOrder: (id: string) => Promise<void>;

  // Dashboard
  metrics: DashboardMetrics | null;
  loadingMetrics: boolean;
  getMetrics: () => Promise<void>;
  getChartData: (period?: string) => Promise<any[]>;
  getPendingPayments: () => Promise<any[]>;

  // Financial
  transactions: FinancialTransaction[];
  loadingTransactions: boolean;
  getTransactions: (params?: any) => Promise<any[]>;
  createTransaction: (data: any) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  
  // Payment functions
  createPayment: (paymentData: any) => Promise<void>;
  markPaymentAsPaid: (orderId: string, amount: number, description: string) => Promise<void>;

  // General
  refreshAll: () => Promise<void>;
}

const ERPContext = createContext<ERPContextType | undefined>(undefined);

export const ERPProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { toast } = useToast();

  // States
  const [products, setProducts] = useState<Product[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [orders, setOrders] = useState<OrdemServico[]>([]);
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [transactions, setTransactions] = useState<FinancialTransaction[]>([]);

  // Loading states
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [loadingClients, setLoadingClients] = useState(false);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [loadingMetrics, setLoadingMetrics] = useState(false);
  const [loadingTransactions, setLoadingTransactions] = useState(false);

  // Error handler
  const handleError = useCallback((error: any, defaultMessage: string) => {
    console.error(error);
    const message = error.message || defaultMessage;
    toast({
      title: "Erro",
      description: message,
      variant: "destructive",
    });
  }, [toast]);

  // Products
  const getProducts = useCallback(async () => {
    setLoadingProducts(true);
    try {
      const data = await productsApi.getAll();
      setProducts(data);
    } catch (error) {
      handleError(error, 'Erro ao carregar produtos');
    } finally {
      setLoadingProducts(false);
    }
  }, [handleError]);

  const createProduct = useCallback(async (formData: FormData) => {
    try {
      await productsApi.create(formData);
      await getProducts();
      toast({
        title: "Sucesso",
        description: "Produto criado com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao criar produto');
      throw error;
    }
  }, [getProducts, handleError, toast]);

  const updateProduct = useCallback(async (id: string, formData: FormData) => {
    try {
      await productsApi.update(id, formData);
      await getProducts();
      toast({
        title: "Sucesso",
        description: "Produto atualizado com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao atualizar produto');
      throw error;
    }
  }, [getProducts, handleError, toast]);

  const deleteProduct = useCallback(async (id: string) => {
    try {
      await productsApi.delete(id);
      await getProducts();
      toast({
        title: "Sucesso",
        description: "Produto removido com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao remover produto');
      throw error;
    }
  }, [getProducts, handleError, toast]);

  // Clients
  const getClients = useCallback(async () => {
    setLoadingClients(true);
    try {
      const data = await clientsApi.getAll();
      setClients(data);
    } catch (error) {
      handleError(error, 'Erro ao carregar clientes');
    } finally {
      setLoadingClients(false);
    }
  }, [handleError]);

  const createClient = useCallback(async (clientData: Partial<Client>) => {
    try {
      await clientsApi.create(clientData);
      await getClients();
      toast({
        title: "Sucesso",
        description: "Cliente criado com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao criar cliente');
      throw error;
    }
  }, [getClients, handleError, toast]);

  const updateClient = useCallback(async (id: string, clientData: Partial<Client>) => {
    try {
      await clientsApi.update(id, clientData);
      await getClients();
      toast({
        title: "Sucesso",
        description: "Cliente atualizado com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao atualizar cliente');
      throw error;
    }
  }, [getClients, handleError, toast]);

  const deleteClient = useCallback(async (id: string) => {
    try {
      await clientsApi.delete(id);
      await getClients();
      toast({
        title: "Sucesso",
        description: "Cliente removido com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao remover cliente');
      throw error;
    }
  }, [getClients, handleError, toast]);

  // Orders
  const getOrders = useCallback(async () => {
    setLoadingOrders(true);
    try {
      const data = await ordersApi.getAll();
      setOrders(data);
    } catch (error) {
      handleError(error, 'Erro ao carregar ordens de serviço');
    } finally {
      setLoadingOrders(false);
    }
  }, [handleError]);

  const createOrder = useCallback(async (orderData: Partial<OrdemServico>) => {
    try {
      await ordersApi.create(orderData);
      await getOrders();
      await getProducts(); // Atualizar disponibilidade dos produtos
      toast({
        title: "Sucesso",
        description: "Ordem de serviço criada com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao criar ordem de serviço');
      throw error;
    }
  }, [getOrders, getProducts, handleError, toast]);

  const updateOrder = useCallback(async (id: string, orderData: Partial<OrdemServico>) => {
    try {
      await ordersApi.update(id, orderData);
      await getOrders();
      await getProducts(); // Atualizar disponibilidade dos produtos
      toast({
        title: "Sucesso",
        description: "Ordem de serviço atualizada com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao atualizar ordem de serviço');
      throw error;
    }
  }, [getOrders, getProducts, handleError, toast]);

  const deleteOrder = useCallback(async (id: string) => {
    try {
      await ordersApi.delete(id);
      await getOrders();
      await getProducts(); // Atualizar disponibilidade dos produtos
      toast({
        title: "Sucesso",
        description: "Ordem de serviço removida com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao remover ordem de serviço');
      throw error;
    }
  }, [getOrders, getProducts, handleError, toast]);

  // Métodos de transações financeiras
  const createFinancialTransaction = useCallback(async (transactionData: any) => {
    try {
      await financialApi.createTransaction(transactionData);
      toast({
        title: "Sucesso",
        description: "Transação financeira criada com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao criar transação financeira');
      throw error;
    }
  }, [handleError, toast]);

  // Método para marcar pagamento como pago e criar transação financeira
  const markPaymentAsPaid = useCallback(async (orderId: string, amount: number, description: string) => {
    try {
      // Criar transação financeira
      await createFinancialTransaction({
        type: 'receita',
        category: 'Pagamento OS',
        amount: amount,
        description: description,
        date: new Date().toISOString().split('T')[0]
      });
      
      // Atualizar ordem reduzindo remaining_amount
      const order = orders.find(o => o.id === orderId);
      if (order) {
        const newRemainingAmount = Math.max(0, order.remaining_amount - amount);
        await updateOrder(orderId, { remaining_amount: newRemainingAmount });
      }
      
      toast({
        title: "Pagamento confirmado!",
        description: "Pagamento registrado e transação financeira criada.",
      });
    } catch (error) {
      handleError(error, 'Erro ao confirmar pagamento');
      throw error;
    }
  }, [orders, updateOrder, createFinancialTransaction, handleError, toast]);
  const getMetrics = useCallback(async () => {
    setLoadingMetrics(true);
    try {
      const data = await dashboardApi.getMetrics();
      setMetrics(data);
    } catch (error) {
      handleError(error, 'Erro ao carregar métricas');
    } finally {
      setLoadingMetrics(false);
    }
  }, [handleError]);

  const getChartData = useCallback(async (period?: string) => {
    try {
      return await dashboardApi.getChartData(period);
    } catch (error) {
      handleError(error, 'Erro ao carregar dados do gráfico');
      return [];
    }
  }, [handleError]);

  const getPendingPayments = useCallback(async () => {
    try {
      return await dashboardApi.getPendingPayments();
    } catch (error) {
      handleError(error, 'Erro ao carregar pagamentos pendentes');
      return [];
    }
  }, [handleError]);

  // Financial
  const getTransactions = useCallback(async (params?: any) => {
    try {
      const transactions = await financialApi.getTransactions(params);
      // Normalize amounts to numbers
      return transactions.map(t => ({
        ...t,
        amount: Number(t.amount ?? 0)
      }));
    } catch (error) {
      handleError(error, 'Erro ao carregar transações');
      return [];
    }
  }, [handleError]);

  const createTransaction = useCallback(async (transactionData: any) => {
    try {
      await financialApi.createTransaction(transactionData);
      await getMetrics(); // Atualizar métricas
      toast({
        title: "Sucesso",
        description: "Transação criada com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao criar transação');
      throw error;
    }
  }, [getMetrics, handleError, toast]);

  const deleteTransaction = useCallback(async (id: string) => {
    try {
      await financialApi.deleteTransaction(id);
      await getMetrics(); // Atualizar métricas
      toast({
        title: "Sucesso",
        description: "Transação excluída com sucesso!",
      });
    } catch (error) {
      handleError(error, 'Erro ao excluir transação');
      throw error;
    }
  }, [getMetrics, handleError, toast]);

  // Payment functions
  const createPayment = useCallback(async (paymentData: any) => {
    try {
      // Corrigir referência: usar order_id em vez de os_id
      const correctedPaymentData = {
        ...paymentData,
        order_id: paymentData.order_id || paymentData.os_id,
        status: paymentData.type === 'parcial' ? 'pago' : 'pendente', // Parciais são marcados como pagos imediatamente
      };

      const payment = await paymentsApi.create(correctedPaymentData);
      
      // Se o pagamento é do tipo 'parcial', criar transação financeira automaticamente e atualizar OS
      if (paymentData.type === 'parcial') {
        const orderId = correctedPaymentData.order_id;
        const order = orders.find(o => o.id === orderId);
        
        // Criar transação financeira
        await createTransaction({
          type: 'receita',
          category: 'Pagamento Parcial',
          amount: paymentData.amount,
          description: `Pagamento parcial OS #${order?.order_number || orderId.slice(-6)} - ${paymentData.method}`,
          date: new Date().toISOString().split('T')[0],
          os_id: orderId,
          payment_id: payment.id
        });

        // Atualizar remaining_amount da OS
        if (order) {
          const newRemainingAmount = Math.max(0, order.remaining_amount - paymentData.amount);
          await updateOrder(orderId, { remaining_amount: newRemainingAmount });
          
          // Atualizar estado local
          setOrders(prev => prev.map(o => 
            o.id === orderId 
              ? { ...o, remaining_amount: newRemainingAmount }
              : o
          ));
        }
      }
      
      toast({
        title: "Sucesso",
        description: paymentData.type === 'parcial' 
          ? "Pagamento parcial registrado e contabilizado!" 
          : "Pagamento criado com sucesso!",
      });

      // Dados já atualizados localmente acima
      
      return payment;
    } catch (error) {
      handleError(error, 'Erro ao criar pagamento');
      throw error;
    }
  }, [createTransaction, orders, updateOrder, setOrders, handleError, toast]);

  // Refresh all data
  const refreshAll = useCallback(async () => {
    await Promise.all([
      getProducts(),
      getClients(),
      getOrders(),
      getMetrics()
    ]);
  }, [getProducts, getClients, getOrders, getMetrics]);

  const value: ERPContextType = {
    // Products
    products,
    loadingProducts,
    getProducts,
    createProduct,
    updateProduct,
    deleteProduct,

    // Clients
    clients,
    loadingClients,
    getClients,
    createClient,
    updateClient,
    deleteClient,

    // Orders
    orders,
    loadingOrders,
    getOrders,
    createOrder,
    updateOrder,
    deleteOrder,

    // Dashboard
    metrics,
    loadingMetrics,
    getMetrics,
    getChartData,
    getPendingPayments,

    // Financial
    transactions,
    loadingTransactions,
    getTransactions,
    createTransaction,
    deleteTransaction,
    createPayment,
    markPaymentAsPaid,

    // General
    refreshAll,
  };

  return (
    <ERPContext.Provider value={value}>
      {children}
    </ERPContext.Provider>
  );
};

export const useERP = () => {
  const context = useContext(ERPContext);
  if (context === undefined) {
    throw new Error('useERP must be used within an ERPProvider');
  }
  return context;
};