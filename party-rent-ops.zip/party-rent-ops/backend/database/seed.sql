-- Seed data for ERP system
-- Execute este script após criar o schema para popular com dados de exemplo

-- Inserir produtos de exemplo
INSERT INTO products (name, category, quantity, available, rent_price, status, images, description) VALUES
('Mesa Redonda 1.5m', 'Mesa', 10, 8, 25.00, 'available', '{}', 'Mesa redonda de 1.5m para eventos'),
('Cadeira Plástica Branca', 'Cadeira', 100, 85, 2.50, 'available', '{}', 'Cadeira plástica branca padrão'),
('Toalha Mesa Redonda Branca', 'Toalha', 20, 18, 8.00, 'available', '{}', 'Toalha branca para mesa redonda'),
('Tenda 6x6m', 'Tenda', 5, 4, 150.00, 'available', '{}', 'Tenda 6x6 metros para eventos'),
('Som Portátil 200W', 'Som', 8, 6, 80.00, 'available', '{}', 'Sistema de som portátil 200W'),
('Microfone sem Fio', 'Som', 15, 12, 15.00, 'available', '{}', 'Microfone sem fio profissional'),
('Mesa Retangular 2.5m', 'Mesa', 12, 10, 30.00, 'available', '{}', 'Mesa retangular 2.5m para eventos'),
('Cadeira Ferro Preta', 'Cadeira', 50, 45, 4.00, 'available', '{}', 'Cadeira de ferro preta'),
('Iluminação LED Colorida', 'Iluminação', 6, 5, 45.00, 'available', '{}', 'Sistema de iluminação LED colorida');

-- Inserir clientes de exemplo
INSERT INTO clients (name, email, phone, document, address_street, address_number, address_city, address_state, address_zipcode) VALUES
('João Silva', 'joao.silva@email.com', '(11) 99999-1111', '12345678901', 'Rua das Flores', '123', 'São Paulo', 'SP', '01234-567'),
('Maria Santos', 'maria.santos@email.com', '(11) 99999-2222', '23456789012', 'Av. Principal', '456', 'São Paulo', 'SP', '02345-678'),
('Pedro Oliveira', 'pedro.oliveira@email.com', '(11) 99999-3333', '34567890123', 'Rua Central', '789', 'São Paulo', 'SP', '03456-789'),
('Ana Costa', 'ana.costa@email.com', '(11) 99999-4444', '45678901234', 'Rua do Comércio', '321', 'São Paulo', 'SP', '04567-890'),
('Carlos Ferreira', 'carlos.ferreira@email.com', '(11) 99999-5555', '56789012345', 'Av. Secundária', '654', 'São Paulo', 'SP', '05678-901');

-- Inserir transações financeiras de exemplo
INSERT INTO financial_transactions (type, category, amount, description, date) VALUES
('receita', 'Locação', 850.00, 'Locação de equipamentos - Evento Aniversário', '2024-01-15'),
('receita', 'Locação', 1200.00, 'Locação de equipamentos - Casamento', '2024-01-20'),
('despesa', 'Manutenção', 150.00, 'Manutenção equipamentos de som', '2024-01-18'),
('receita', 'Locação', 650.00, 'Locação de equipamentos - Festa Corporativa', '2024-01-25'),
('despesa', 'Combustível', 80.00, 'Combustível para entrega', '2024-01-22'),
('receita', 'Locação', 950.00, 'Locação de equipamentos - Formatura', '2024-01-28'),
('despesa', 'Material', 200.00, 'Compra de toalhas novas', '2024-01-30'),
('receita', 'Locação', 750.00, 'Locação de equipamentos - Aniversário', '2024-02-05'),
('despesa', 'Manutenção', 120.00, 'Limpeza de equipamentos', '2024-02-08'),
('receita', 'Locação', 1100.00, 'Locação de equipamentos - Evento Empresarial', '2024-02-10');

-- Inserir ordens de serviço de exemplo
DO $$
DECLARE
    client1_id UUID;
    client2_id UUID;
    product1_id UUID;
    product2_id UUID;
    order1_id UUID;
    order2_id UUID;
BEGIN
    -- Pegar IDs dos clientes e produtos
    SELECT id INTO client1_id FROM clients WHERE name = 'João Silva' LIMIT 1;
    SELECT id INTO client2_id FROM clients WHERE name = 'Maria Santos' LIMIT 1;
    SELECT id INTO product1_id FROM products WHERE name = 'Mesa Redonda 1.5m' LIMIT 1;
    SELECT id INTO product2_id FROM products WHERE name = 'Cadeira Plástica Branca' LIMIT 1;
    
    -- Inserir ordens de serviço
    INSERT INTO orders (id, client_id, start_date, end_date, total_amount, signal_amount, remaining_amount, status, delivery_address, notes)
    VALUES 
        (uuid_generate_v4(), client1_id, '2024-02-15', '2024-02-16', 850.00, 300.00, 550.00, 'confirmado', 'Rua das Flores, 123', 'Evento de aniversário'),
        (uuid_generate_v4(), client2_id, '2024-02-20', '2024-02-21', 1200.00, 500.00, 700.00, 'em_andamento', 'Av. Principal, 456', 'Casamento')
    RETURNING id INTO order1_id;
    
    -- Pegar o ID da primeira ordem criada
    SELECT id INTO order1_id FROM orders WHERE client_id = client1_id LIMIT 1;
    SELECT id INTO order2_id FROM orders WHERE client_id = client2_id LIMIT 1;
    
    -- Inserir itens das ordens
    INSERT INTO order_items (order_id, product_id, quantity, days, unit_price, total)
    VALUES 
        (order1_id, product1_id, 5, 2, 25.00, 250.00),
        (order1_id, product2_id, 40, 2, 2.50, 200.00),
        (order2_id, product1_id, 8, 2, 25.00, 400.00),
        (order2_id, product2_id, 60, 2, 2.50, 300.00);
    
    -- Inserir pagamentos
    INSERT INTO payments (order_id, amount, type, method, status, due_date)
    VALUES 
        (order1_id, 300.00, 'sinal', 'pix', 'pago', '2024-02-14'),
        (order1_id, 550.00, 'final', 'dinheiro', 'pendente', '2024-02-16'),
        (order2_id, 500.00, 'sinal', 'cartao_credito', 'pago', '2024-02-19'),
        (order2_id, 700.00, 'final', 'pix', 'pendente', '2024-02-21');
    
    -- Inserir eventos da agenda
    INSERT INTO agenda_events (order_id, type, date, time, title, description, status)
    VALUES 
        (order1_id, 'entrega', '2024-02-15', '09:00', 'Entrega - Aniversário João', 'Entrega de equipamentos para aniversário', 'agendado'),
        (order1_id, 'retirada', '2024-02-16', '18:00', 'Retirada - Aniversário João', 'Retirada de equipamentos após evento', 'agendado'),
        (order2_id, 'entrega', '2024-02-20', '08:00', 'Entrega - Casamento Maria', 'Entrega de equipamentos para casamento', 'agendado'),
        (order2_id, 'retirada', '2024-02-21', '22:00', 'Retirada - Casamento Maria', 'Retirada de equipamentos após casamento', 'agendado');
        
END $$;