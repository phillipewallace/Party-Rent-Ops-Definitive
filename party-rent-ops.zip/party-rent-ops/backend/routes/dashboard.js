const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// GET /api/dashboard/metrics - Métricas do dashboard
router.get('/metrics', async (req, res) => {
  try {
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
    
    // Receita mensal
    const revenueResult = await query(
      `SELECT COALESCE(SUM(amount), 0) as monthly_revenue 
       FROM financial_transactions 
       WHERE type = 'receita' AND DATE_TRUNC('month', date) = DATE_TRUNC('month', CURRENT_DATE)`
    );

    // Despesas mensais
    const expensesResult = await query(
      `SELECT COALESCE(SUM(amount), 0) as monthly_expenses 
       FROM financial_transactions 
       WHERE type = 'despesa' AND DATE_TRUNC('month', date) = DATE_TRUNC('month', CURRENT_DATE)`
    );

    // Produtos em estoque
    const stockResult = await query(
      'SELECT COALESCE(SUM(quantity), 0) as products_in_stock FROM products'
    );

    // Pagamentos pendentes
    const pendingPaymentsResult = await query(
      `SELECT COUNT(*) as pending_payments 
       FROM payments 
       WHERE status = 'pendente'`
    );

    // Pedidos ativos
    const activeOrdersResult = await query(
      `SELECT COUNT(*) as active_orders 
       FROM orders 
       WHERE status IN ('confirmado', 'em_andamento')`
    );

    // Produtos disponíveis
    const availableProductsResult = await query(
      `SELECT COALESCE(SUM(available), 0) as available_products 
       FROM products 
       WHERE status = 'available'`
    );

    const metrics = {
      monthlyRevenue: parseFloat(revenueResult.rows[0].monthly_revenue),
      monthlyExpenses: parseFloat(expensesResult.rows[0].monthly_expenses),
      productsInStock: parseInt(stockResult.rows[0].products_in_stock),
      pendingPayments: parseInt(pendingPaymentsResult.rows[0].pending_payments),
      activeOrders: parseInt(activeOrdersResult.rows[0].active_orders),
      availableProducts: parseInt(availableProductsResult.rows[0].available_products)
    };

    res.json(metrics);
  } catch (error) {
    console.error('Erro ao buscar métricas:', error);
    res.status(500).json({ error: 'Erro ao buscar métricas do dashboard' });
  }
});

// GET /api/dashboard/chart-data - Dados para gráficos
router.get('/chart-data', async (req, res) => {
  try {
    const { period = '7' } = req.query; // últimos 7, 30 ou 90 dias

    const chartData = await query(
      `SELECT 
         DATE(date) as date,
         COALESCE(SUM(CASE WHEN type = 'receita' THEN amount ELSE 0 END), 0) as revenue,
         COALESCE(SUM(CASE WHEN type = 'despesa' THEN amount ELSE 0 END), 0) as expenses
       FROM financial_transactions 
       WHERE date >= CURRENT_DATE - INTERVAL '${parseInt(period)} days'
       GROUP BY DATE(date)
       ORDER BY date ASC`
    );

    res.json(chartData.rows);
  } catch (error) {
    console.error('Erro ao buscar dados do gráfico:', error);
    res.status(500).json({ error: 'Erro ao buscar dados do gráfico' });
  }
});

// GET /api/dashboard/pending-payments - Pagamentos pendentes
router.get('/pending-payments', async (req, res) => {
  try {
    const result = await query(
      `SELECT 
         p.*,
         o.id as order_id,
         c.name as client_name
       FROM payments p
       JOIN orders o ON p.order_id = o.id
       JOIN clients c ON o.client_id = c.id
       WHERE p.status = 'pendente'
       ORDER BY p.due_date ASC
       LIMIT 10`
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao buscar pagamentos pendentes:', error);
    res.status(500).json({ error: 'Erro ao buscar pagamentos pendentes' });
  }
});

// GET /api/dashboard/recent-orders - Pedidos recentes
router.get('/recent-orders', async (req, res) => {
  try {
    const result = await query(
      `SELECT 
         o.*,
         c.name as client_name,
         c.phone as client_phone
       FROM orders o
       JOIN clients c ON o.client_id = c.id
       ORDER BY o.created_at DESC
       LIMIT 5`
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao buscar pedidos recentes:', error);
    res.status(500).json({ error: 'Erro ao buscar pedidos recentes' });
  }
});

module.exports = router;