const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Configuração do multer para upload de imagens
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = './uploads/products';
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'product-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Apenas imagens são permitidas!'));
    }
  }
});

// GET /api/products - Listar todos os produtos
router.get('/', async (req, res) => {
  try {
    const { category, status, search } = req.query;
    let sql = 'SELECT * FROM products WHERE 1=1';
    const params = [];
    let paramCount = 0;

    if (category) {
      paramCount++;
      sql += ` AND category = $${paramCount}`;
      params.push(category);
    }

    if (status) {
      paramCount++;
      sql += ` AND status = $${paramCount}`;
      params.push(status);
    }

    if (search) {
      paramCount++;
      sql += ` AND (name ILIKE $${paramCount} OR description ILIKE $${paramCount})`;
      params.push(`%${search}%`);
    }

    sql += ' ORDER BY name ASC';

    const result = await query(sql, params);
      // Mapear para o formato esperado pelo frontend
      const products = result.rows.map(row => ({
        id: row.id,
        name: row.name,
        category: row.category,
        quantity: row.quantity,
        available: row.available,
        rentPrice: parseFloat(row.rent_price) || 0,
        status: row.status,
        images: row.images || [],
        description: row.description,
        created_at: row.created_at,
        updated_at: row.updated_at
      }));
    res.json(products);
  } catch (error) {
    console.error('Erro ao buscar produtos:', error);
    res.status(500).json({ error: 'Erro ao buscar produtos' });
  }
});

// GET /api/products/:id - Buscar produto por ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await query('SELECT * FROM products WHERE id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    // Mapear campos do banco para o formato do frontend
    const product = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      category: result.rows[0].category,
      quantity: result.rows[0].quantity,
      available: result.rows[0].available,
      rentPrice: parseFloat(result.rows[0].rent_price) || 0,
      status: result.rows[0].status,
      images: result.rows[0].images || [],
      description: result.rows[0].description,
      created_at: result.rows[0].created_at,
      updated_at: result.rows[0].updated_at
    };
    res.json(product);
  } catch (error) {
    console.error('Erro ao buscar produto:', error);
    res.status(500).json({ error: 'Erro ao buscar produto' });
  }
});

// POST /api/products - Criar novo produto
router.post('/', upload.array('images', 5), async (req, res) => {
  try {
    const { name, category, quantity, available, rent_price, description } = req.body;
    
    // URLs das imagens uploadadas
    const images = req.files ? req.files.map(file => `/uploads/products/${file.filename}`) : [];
    
    // Determinar status baseado na quantidade
    let status = 'available';
    if (available === 0) status = 'out_of_stock';
    else if (available < 5) status = 'low_stock';

    const result = await query(
      `INSERT INTO products (name, category, quantity, available, rent_price, status, images, description) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [name, category, parseInt(quantity), parseInt(available), parseFloat(rent_price), status, images, description]
    );

    // Mapear campos do banco para o formato do frontend
    const product = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      category: result.rows[0].category,
      quantity: result.rows[0].quantity,
      available: result.rows[0].available,
      rentPrice: parseFloat(result.rows[0].rent_price) || 0,
      status: result.rows[0].status,
      images: result.rows[0].images || [],
      description: result.rows[0].description,
      created_at: result.rows[0].created_at,
      updated_at: result.rows[0].updated_at
    };

    res.status(201).json(product);
  } catch (error) {
    console.error('Erro ao criar produto:', error);
    res.status(500).json({ error: 'Erro ao criar produto' });
  }
});

// PUT /api/products/:id - Atualizar produto
router.put('/:id', upload.array('images', 5), async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, quantity, available, rent_price, description, existing_images } = req.body;
    
    // Combinar imagens existentes com novas
    let images = [];
    if (existing_images) {
      images = Array.isArray(existing_images) ? existing_images : [existing_images];
    }
    if (req.files && req.files.length > 0) {
      const newImages = req.files.map(file => `/uploads/products/${file.filename}`);
      images = [...images, ...newImages];
    }
    
    // Determinar status baseado na quantidade
    let status = 'available';
    if (available === 0) status = 'out_of_stock';
    else if (available < 5) status = 'low_stock';

    const result = await query(
      `UPDATE products SET 
       name = $1, category = $2, quantity = $3, available = $4, 
       rent_price = $5, status = $6, images = $7, description = $8,
       updated_at = CURRENT_TIMESTAMP
       WHERE id = $9 RETURNING *`,
      [name, category, parseInt(quantity), parseInt(available), parseFloat(rent_price), status, images, description, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    // Mapear campos do banco para o formato do frontend
    const product = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      category: result.rows[0].category,
      quantity: result.rows[0].quantity,
      available: result.rows[0].available,
      rentPrice: parseFloat(result.rows[0].rent_price) || 0,
      status: result.rows[0].status,
      images: result.rows[0].images || [],
      description: result.rows[0].description,
      created_at: result.rows[0].created_at,
      updated_at: result.rows[0].updated_at
    };

    res.json(product);
  } catch (error) {
    console.error('Erro ao atualizar produto:', error);
    res.status(500).json({ error: 'Erro ao atualizar produto' });
  }
});

// DELETE /api/products/:id - Deletar produto
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Buscar produto para deletar imagens
    const product = await query('SELECT images FROM products WHERE id = $1', [id]);
    
    const result = await query('DELETE FROM products WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    // Deletar imagens do sistema de arquivos
    if (product.rows[0].images && product.rows[0].images.length > 0) {
      const productImages = product.rows[0].images || [];
      productImages.forEach(imagePath => {
        const fullPath = path.join(__dirname, '..', imagePath);
        if (fs.existsSync(fullPath)) {
          fs.unlinkSync(fullPath);
        }
      });
    }

    res.json({ message: 'Produto deletado com sucesso' });
  } catch (error) {
    console.error('Erro ao deletar produto:', error);
    res.status(500).json({ error: 'Erro ao deletar produto' });
  }
});

// GET /api/products/categories - Listar categorias disponíveis
router.get('/meta/categories', async (req, res) => {
  try {
    const result = await query('SELECT DISTINCT category FROM products ORDER BY category');
    const categories = result.rows.map(row => row.category);
    res.json(categories);
  } catch (error) {
    console.error('Erro ao buscar categorias:', error);
    res.status(500).json({ error: 'Erro ao buscar categorias' });
  }
});

module.exports = router;