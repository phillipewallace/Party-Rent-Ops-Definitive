const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// GET /api/clients - Listar todos os clientes
router.get('/', async (req, res) => {
  try {
    const { search } = req.query;
    let sql = 'SELECT * FROM clients WHERE 1=1';
    const params = [];

    if (search) {
      sql += ` AND (name ILIKE $1 OR email ILIKE $1 OR phone ILIKE $1 OR document ILIKE $1)`;
      params.push(`%${search}%`);
    }

    sql += ' ORDER BY name ASC';

    const result = await query(sql, params);
    
    // Transformar dados para o formato esperado pelo frontend
    const clients = result.rows.map(row => ({
      id: row.id,
      name: row.name,
      email: row.email,
      phone: row.phone,
      document: row.document,
      address: {
        street: row.address_street,
        number: row.address_number,
        complement: row.address_complement,
        city: row.address_city,
        state: row.address_state,
        zipCode: row.address_zipcode
      },
      created_at: row.created_at,
      updated_at: row.updated_at
    }));

    res.json(clients);
  } catch (error) {
    console.error('Erro ao buscar clientes:', error);
    res.status(500).json({ error: 'Erro ao buscar clientes' });
  }
});

// GET /api/clients/:id - Buscar cliente por ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await query('SELECT * FROM clients WHERE id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Cliente não encontrado' });
    }
    
    const row = result.rows[0];
    const client = {
      id: row.id,
      name: row.name,
      email: row.email,
      phone: row.phone,
      document: row.document,
      address: {
        street: row.address_street,
        number: row.address_number,
        complement: row.address_complement,
        city: row.address_city,
        state: row.address_state,
        zipCode: row.address_zipcode
      },
      created_at: row.created_at,
      updated_at: row.updated_at
    };
    
    res.json(client);
  } catch (error) {
    console.error('Erro ao buscar cliente:', error);
    res.status(500).json({ error: 'Erro ao buscar cliente' });
  }
});

// POST /api/clients - Criar novo cliente
router.post('/', async (req, res) => {
  try {
    const { name, email, phone, document, address } = req.body;
    
    const result = await query(
      `INSERT INTO clients (name, email, phone, document, address_street, address_number, 
       address_complement, address_city, address_state, address_zipcode) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [
        name, email, phone, document,
        address?.street, address?.number, address?.complement,
        address?.city, address?.state, address?.zipCode
      ]
    );

    const row = result.rows[0];
    const client = {
      id: row.id,
      name: row.name,
      email: row.email,
      phone: row.phone,
      document: row.document,
      address: {
        street: row.address_street,
        number: row.address_number,
        complement: row.address_complement,
        city: row.address_city,
        state: row.address_state,
        zipCode: row.address_zipcode
      },
      created_at: row.created_at,
      updated_at: row.updated_at
    };

    res.status(201).json(client);
  } catch (error) {
    console.error('Erro ao criar cliente:', error);
    if (error.code === '23505') { // Violação de unique constraint
      res.status(400).json({ error: 'Cliente com este documento já existe' });
    } else {
      res.status(500).json({ error: 'Erro ao criar cliente' });
    }
  }
});

// PUT /api/clients/:id - Atualizar cliente
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, phone, document, address } = req.body;

    const result = await query(
      `UPDATE clients SET 
       name = $1, email = $2, phone = $3, document = $4,
       address_street = $5, address_number = $6, address_complement = $7,
       address_city = $8, address_state = $9, address_zipcode = $10,
       updated_at = CURRENT_TIMESTAMP
       WHERE id = $11 RETURNING *`,
      [
        name, email, phone, document,
        address?.street, address?.number, address?.complement,
        address?.city, address?.state, address?.zipCode,
        id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Cliente não encontrado' });
    }

    const row = result.rows[0];
    const client = {
      id: row.id,
      name: row.name,
      email: row.email,
      phone: row.phone,
      document: row.document,
      address: {
        street: row.address_street,
        number: row.address_number,
        complement: row.address_complement,
        city: row.address_city,
        state: row.address_state,
        zipCode: row.address_zipcode
      },
      created_at: row.created_at,
      updated_at: row.updated_at
    };

    res.json(client);
  } catch (error) {
    console.error('Erro ao atualizar cliente:', error);
    if (error.code === '23505') {
      res.status(400).json({ error: 'Cliente com este documento já existe' });
    } else {
      res.status(500).json({ error: 'Erro ao atualizar cliente' });
    }
  }
});

// DELETE /api/clients/:id - Deletar cliente
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar se cliente tem ordens de serviço
    const ordersCheck = await query('SELECT COUNT(*) as count FROM orders WHERE client_id = $1', [id]);
    if (parseInt(ordersCheck.rows[0].count) > 0) {
      return res.status(400).json({ 
        error: 'Não é possível deletar cliente com ordens de serviço associadas' 
      });
    }
    
    const result = await query('DELETE FROM clients WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Cliente não encontrado' });
    }

    res.json({ message: 'Cliente deletado com sucesso' });
  } catch (error) {
    console.error('Erro ao deletar cliente:', error);
    res.status(500).json({ error: 'Erro ao deletar cliente' });
  }
});

module.exports = router;