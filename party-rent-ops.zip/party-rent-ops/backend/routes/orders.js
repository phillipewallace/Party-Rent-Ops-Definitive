const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// GET /api/orders - Listar todas as ordens
router.get('/', async (req, res) => {
  try {
    const { status, client_id, search } = req.query;
    let sql = `
      SELECT o.*, c.name as client_name, c.phone as client_phone, c.email as client_email
      FROM orders o
      JOIN clients c ON o.client_id = c.id
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (status) {
      paramCount++;
      sql += ` AND o.status = $${paramCount}`;
      params.push(status);
    }

    if (client_id) {
      paramCount++;
      sql += ` AND o.client_id = $${paramCount}`;
      params.push(client_id);
    }

    if (search) {
      paramCount++;
      sql += ` AND (c.name ILIKE $${paramCount} OR o.id::text ILIKE $${paramCount})`;
      params.push(`%${search}%`);
    }

    sql += ' ORDER BY o.created_at DESC';

    const ordersResult = await query(sql, params);
    
    // Buscar itens para cada ordem
    const orders = [];
    for (const orderRow of ordersResult.rows) {
      const itemsResult = await query(`
        SELECT oi.*, p.name as product_name, p.category as product_category
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = $1
      `, [orderRow.id]);

      const order = {
        id: orderRow.id,
        client_id: orderRow.client_id,
        client: {
          id: orderRow.client_id,
          name: orderRow.client_name,
          phone: orderRow.client_phone,
          email: orderRow.client_email
        },
        products: itemsResult.rows.map(item => ({
          product_id: item.product_id,
          product: {
            id: item.product_id,
            name: item.product_name,
            category: item.product_category
          },
          quantity: item.quantity,
          days: item.days,
          unit_price: parseFloat(item.unit_price),
          total: parseFloat(item.total)
        })),
        start_date: orderRow.start_date,
        end_date: orderRow.end_date,
        total_amount: parseFloat(orderRow.total_amount),
        signal_amount: parseFloat(orderRow.signal_amount),
        remaining_amount: parseFloat(orderRow.remaining_amount),
        status: orderRow.status,
        delivery_address: orderRow.delivery_address,
        notes: orderRow.notes,
        created_at: orderRow.created_at,
        updated_at: orderRow.updated_at
      };

      orders.push(order);
    }

    res.json(orders);
  } catch (error) {
    console.error('Erro ao buscar ordens:', error);
    res.status(500).json({ error: 'Erro ao buscar ordens de serviço' });
  }
});

// GET /api/orders/:id - Buscar ordem por ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const orderResult = await query(`
      SELECT o.*, c.name as client_name, c.phone as client_phone, c.email as client_email,
             c.document as client_document, c.address_street, c.address_number, 
             c.address_city, c.address_state, c.address_zipcode
      FROM orders o
      JOIN clients c ON o.client_id = c.id
      WHERE o.id = $1
    `, [id]);

    if (orderResult.rows.length === 0) {
      return res.status(404).json({ error: 'Ordem de serviço não encontrada' });
    }

    const orderRow = orderResult.rows[0];

    // Buscar itens da ordem
    const itemsResult = await query(`
      SELECT oi.*, p.name as product_name, p.category as product_category, p.rent_price
      FROM order_items oi
      JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = $1
    `, [id]);

    const order = {
      id: orderRow.id,
      client_id: orderRow.client_id,
      client: {
        id: orderRow.client_id,
        name: orderRow.client_name,
        phone: orderRow.client_phone,
        email: orderRow.client_email,
        document: orderRow.client_document,
        address: {
          street: orderRow.address_street,
          number: orderRow.address_number,
          city: orderRow.address_city,
          state: orderRow.address_state,
          zipCode: orderRow.address_zipcode
        }
      },
      products: itemsResult.rows.map(item => ({
        product_id: item.product_id,
        product: {
          id: item.product_id,
          name: item.product_name,
          category: item.product_category,
          rentPrice: parseFloat(item.rent_price)
        },
        quantity: item.quantity,
        days: item.days,
        unit_price: parseFloat(item.unit_price),
        total: parseFloat(item.total)
      })),
      start_date: orderRow.start_date,
      end_date: orderRow.end_date,
      total_amount: parseFloat(orderRow.total_amount),
      signal_amount: parseFloat(orderRow.signal_amount),
      remaining_amount: parseFloat(orderRow.remaining_amount),
      status: orderRow.status,
      delivery_address: orderRow.delivery_address,
      notes: orderRow.notes,
      created_at: orderRow.created_at,
      updated_at: orderRow.updated_at
    };

    res.json(order);
  } catch (error) {
    console.error('Erro ao buscar ordem:', error);
    res.status(500).json({ error: 'Erro ao buscar ordem de serviço' });
  }
});

// POST /api/orders - Criar nova ordem
router.post('/', async (req, res) => {
  const client = await query('BEGIN');
  
  try {
    const { 
      client_id, products, start_date, end_date, 
      total_amount, signal_amount, delivery_address, notes 
    } = req.body;

    const remaining_amount = total_amount - signal_amount;

    // Criar ordem
    const orderResult = await query(
      `INSERT INTO orders (client_id, start_date, end_date, total_amount, signal_amount, 
       remaining_amount, delivery_address, notes) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [client_id, start_date, end_date, total_amount, signal_amount, remaining_amount, delivery_address, notes]
    );

    const orderId = orderResult.rows[0].id;
    const orderNumber = orderResult.rows[0].order_number;

    // Criar itens da ordem
    for (const item of products) {
      await query(
        `INSERT INTO order_items (order_id, product_id, quantity, days, unit_price, total)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [orderId, item.product_id, item.quantity, item.days, item.unit_price, item.total]
      );

      // Atualizar disponibilidade do produto
      await query(
        'UPDATE products SET available = available - $1 WHERE id = $2',
        [item.quantity, item.product_id]
      );
    }

    await query('COMMIT');

    // Buscar ordem completa para retornar
    const fullOrder = await query(`
      SELECT o.*, c.name as client_name, c.phone as client_phone
      FROM orders o
      JOIN clients c ON o.client_id = c.id
      WHERE o.id = $1
    `, [orderId]);

    res.status(201).json(fullOrder.rows[0]);
  } catch (error) {
    await query('ROLLBACK');
    console.error('Erro ao criar ordem:', error);
    res.status(500).json({ error: 'Erro ao criar ordem de serviço' });
  }
});

// PUT /api/orders/:id - Atualizar ordem
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // Se é apenas atualização de status ou remaining_amount
    if ((Object.keys(updateData).length === 1 && updateData.status) || 
        (Object.keys(updateData).length === 1 && updateData.remaining_amount !== undefined) ||
        (Object.keys(updateData).length === 2 && updateData.status && updateData.remaining_amount !== undefined)) {
      const currentOrder = await query('SELECT * FROM orders WHERE id = $1', [id]);
      if (currentOrder.rows.length === 0) {
        return res.status(404).json({ error: 'Ordem não encontrada' });
      }

      // Atualizar status ou remaining_amount
      if (updateData.status) {
        await query(
          'UPDATE orders SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [updateData.status, id]
        );
      }
      
      if (updateData.remaining_amount !== undefined) {
        await query(
          'UPDATE orders SET remaining_amount = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [updateData.remaining_amount, id]
        );
      }

      // Lógica de estoque baseada na mudança de status
      const currentOrderData = currentOrder.rows[0];
      const reserveStatuses = ['confirmado', 'em_andamento'];
      const releaseStatuses = ['finalizado', 'cancelado'];
      
      // Se mudou para status que reserva produtos
      if (reserveStatuses.includes(updateData.status) && !reserveStatuses.includes(currentOrderData.status)) {
        // OS foi ativada - reservar produtos
        const orderItems = await query(
          'SELECT product_id, quantity FROM order_items WHERE order_id = $1',
          [id]
        );

        for (const item of orderItems.rows) {
          await query(
            'UPDATE products SET available = available - $1 WHERE id = $2',
            [item.quantity, item.product_id]
          );
        }
      } else if (releaseStatuses.includes(updateData.status) && reserveStatuses.includes(currentOrderData.status)) {
        // OS foi finalizada/cancelada - liberar produtos de volta ao estoque
        const orderItems = await query(
          'SELECT product_id, quantity FROM order_items WHERE order_id = $1',
          [id]
        );

        for (const item of orderItems.rows) {
          await query(
            'UPDATE products SET available = available + $1 WHERE id = $2',
            [item.quantity, item.product_id]
          );
        }
      } else if (reserveStatuses.includes(currentOrderData.status) && updateData.status === 'orcamento') {
        // OS voltou para orçamento - liberar produtos
        const orderItems = await query(
          'SELECT product_id, quantity FROM order_items WHERE order_id = $1',
          [id]
        );

        for (const item of orderItems.rows) {
          await query(
            'UPDATE products SET available = available + $1 WHERE id = $2',
            [item.quantity, item.product_id]
          );
        }
      }

      return res.json({ message: 'Status atualizado com sucesso' });
    }

    // Atualização completa da ordem
    const client = await query('BEGIN');
    
    try {
      const { 
        client_id, products, start_date, end_date, 
        total_amount, signal_amount, delivery_address, notes, status 
      } = updateData;

      const remaining_amount = total_amount - signal_amount;

      // Buscar produtos atuais para restaurar disponibilidade
      const currentItems = await query(
        'SELECT product_id, quantity FROM order_items WHERE order_id = $1',
        [id]
      );

      // Restaurar disponibilidade dos produtos anteriores
      for (const item of currentItems.rows) {
        await query(
          'UPDATE products SET available = available + $1 WHERE id = $2',
          [item.quantity, item.product_id]
        );
      }

      // Deletar itens atuais
      await query('DELETE FROM order_items WHERE order_id = $1', [id]);

      // Atualizar ordem
      await query(
        `UPDATE orders SET 
         client_id = $1, start_date = $2, end_date = $3, total_amount = $4,
         signal_amount = $5, remaining_amount = $6, delivery_address = $7, 
         notes = $8, status = $9, updated_at = CURRENT_TIMESTAMP
         WHERE id = $10`,
        [client_id, start_date, end_date, total_amount, signal_amount, 
         remaining_amount, delivery_address, notes, status || 'orcamento', id]
      );

      // Criar novos itens
      for (const item of products) {
        await query(
          `INSERT INTO order_items (order_id, product_id, quantity, days, unit_price, total)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [id, item.product_id, item.quantity, item.days, item.unit_price, item.total]
        );

        // Reduzir disponibilidade
        await query(
          'UPDATE products SET available = available - $1 WHERE id = $2',
          [item.quantity, item.product_id]
        );
      }

      await query('COMMIT');

      res.json({ message: 'Ordem atualizada com sucesso' });
    } catch (error) {
      await query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Erro ao atualizar ordem:', error);
    res.status(500).json({ error: 'Erro ao atualizar ordem de serviço' });
  }
});

// DELETE /api/orders/:id - Deletar ordem
router.delete('/:id', async (req, res) => {
  const client = await query('BEGIN');
  
  try {
    const { id } = req.params;
    
    // Buscar itens para restaurar disponibilidade
    const items = await query(
      'SELECT product_id, quantity FROM order_items WHERE order_id = $1',
      [id]
    );

    // Restaurar disponibilidade dos produtos
    for (const item of items.rows) {
      await query(
        'UPDATE products SET available = available + $1 WHERE id = $2',
        [item.quantity, item.product_id]
      );
    }

    // Deletar ordem (cascade vai deletar itens, pagamentos, eventos)
    const result = await query('DELETE FROM orders WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      await query('ROLLBACK');
      return res.status(404).json({ error: 'Ordem não encontrada' });
    }

    await query('COMMIT');
    res.json({ message: 'Ordem deletada com sucesso' });
  } catch (error) {
    await query('ROLLBACK');
    console.error('Erro ao deletar ordem:', error);
    res.status(500).json({ error: 'Erro ao deletar ordem de serviço' });
  }
});

module.exports = router;