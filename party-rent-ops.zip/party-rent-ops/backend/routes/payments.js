const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// GET /api/payments - Listar pagamentos
router.get('/', async (req, res) => {
  try {
    const { order_id, status } = req.query;
    let sql = 'SELECT * FROM payments WHERE 1=1';
    const params = [];
    let paramCount = 0;

    if (order_id) {
      paramCount++;
      sql += ` AND order_id = $${paramCount}`;
      params.push(order_id);
    }

    if (status) {
      paramCount++;
      sql += ` AND status = $${paramCount}`;
      params.push(status);
    }

    sql += ' ORDER BY due_date ASC';

    const result = await query(sql, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao buscar pagamentos:', error);
    res.status(500).json({ error: 'Erro ao buscar pagamentos' });
  }
});

// POST /api/payments - Criar pagamento
router.post('/', async (req, res) => {
  try {
    const { order_id, amount, type, method, due_date, status = 'pendente' } = req.body;
    
    // Validações
    if (!order_id || !amount || !type || !method) {
      return res.status(400).json({ error: 'Campos obrigatórios não informados' });
    }

    if (amount <= 0) {
      return res.status(400).json({ error: 'Valor deve ser maior que zero' });
    }

    // Verificar se a ordem existe
    const orderCheck = await query('SELECT remaining_amount FROM orders WHERE id = $1', [order_id]);
    if (orderCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Ordem de serviço não encontrada' });
    }

    // Verificar se o valor não excede o remaining_amount
    const remainingAmount = parseFloat(orderCheck.rows[0].remaining_amount || 0);
    if (parseFloat(amount) > remainingAmount) {
      return res.status(400).json({ error: 'Valor excede o valor pendente da OS' });
    }
    
    const result = await query(
      `INSERT INTO payments (order_id, amount, type, method, due_date, status, created_at) 
       VALUES ($1, $2, $3, $4, $5, $6, NOW()) RETURNING *`,
      [order_id, amount, type, method, due_date, status]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao criar pagamento:', error);
    res.status(500).json({ error: 'Erro ao criar pagamento' });
  }
});

// PUT /api/payments/:id - Atualizar pagamento
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, paid_date } = req.body;
    
    const result = await query(
      `UPDATE payments SET status = $1, paid_date = $2, updated_at = NOW() 
       WHERE id = $3 RETURNING *`,
      [status, paid_date, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Pagamento não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao atualizar pagamento:', error);
    res.status(500).json({ error: 'Erro ao atualizar pagamento' });
  }
});

// POST /api/payments/:id/mark-paid - Marcar pagamento como pago
router.post('/:id/mark-paid', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await query(
      `UPDATE payments SET status = 'pago', paid_date = NOW(), updated_at = NOW() 
       WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Pagamento não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao marcar pagamento como pago:', error);
    res.status(500).json({ error: 'Erro ao marcar pagamento como pago' });
  }
});

// DELETE /api/payments/:id - Deletar pagamento
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await query('DELETE FROM payments WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Pagamento não encontrado' });
    }

    res.json({ message: 'Pagamento excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir pagamento:', error);
    res.status(500).json({ error: 'Erro ao excluir pagamento' });
  }
});

module.exports = router;