const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// GET /api/agenda/events - Listar eventos
router.get('/events', async (req, res) => {
  try {
    const { date, type } = req.query;
    let sql = 'SELECT * FROM agenda_events WHERE 1=1';
    const params = [];
    let paramCount = 0;

    if (date) {
      paramCount++;
      sql += ` AND date = $${paramCount}`;
      params.push(date);
    }

    if (type) {
      paramCount++;
      sql += ` AND type = $${paramCount}`;
      params.push(type);
    }

    sql += ' ORDER BY date ASC, time ASC';

    const result = await query(sql, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao buscar eventos:', error);
    res.status(500).json({ error: 'Erro ao buscar eventos da agenda' });
  }
});

// POST /api/agenda/events - Criar evento
router.post('/events', async (req, res) => {
  try {
    const { order_id, type, date, time, title, description, status = 'agendado' } = req.body;
    
    // Mapear tipos do frontend para tipos válidos do banco
    const validType = type === 'outros' ? 'locacao_ativa' : type;
    
    const result = await query(
      `INSERT INTO agenda_events (order_id, type, date, time, title, description, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [order_id, validType, date, time, title, description, status]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao criar evento:', error);
    res.status(500).json({ error: 'Erro ao criar evento da agenda' });
  }
});

// PUT /api/agenda/events/:id - Atualizar evento
router.put('/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { order_id, type, date, time, title, description, status } = req.body;
    
    // Mapear tipos do frontend para tipos válidos do banco
    const validType = type === 'outros' ? 'locacao_ativa' : type;

    const result = await query(
      `UPDATE agenda_events SET 
       order_id = $1, type = $2, date = $3, time = $4, 
       title = $5, description = $6, status = $7
       WHERE id = $8 RETURNING *`,
      [order_id, validType, date, time, title, description, status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao atualizar evento:', error);
    res.status(500).json({ error: 'Erro ao atualizar evento da agenda' });
  }
});

// DELETE /api/agenda/events/:id - Deletar evento
router.delete('/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await query('DELETE FROM agenda_events WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }

    res.json({ message: 'Evento deletado com sucesso' });
  } catch (error) {
    console.error('Erro ao deletar evento:', error);
    res.status(500).json({ error: 'Erro ao deletar evento da agenda' });
  }
});

module.exports = router;