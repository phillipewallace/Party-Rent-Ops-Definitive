const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// GET /api/financial/transactions - Listar transações
router.get('/transactions', async (req, res) => {
  try {
    const { type, period = '30' } = req.query;
    let sql = 'SELECT * FROM financial_transactions WHERE 1=1';
    const params = [];
    let paramCount = 0;

    if (type) {
      paramCount++;
      sql += ` AND type = $${paramCount}`;
      params.push(type);
    }

    paramCount++;
    sql += ` AND date >= CURRENT_DATE - INTERVAL '${parseInt(period)} days'`;

    sql += ' ORDER BY date DESC';

    const result = await query(sql, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao buscar transações:', error);
    res.status(500).json({ error: 'Erro ao buscar transações financeiras' });
  }
});

// POST /api/financial/transactions - Criar transação
router.post('/transactions', async (req, res) => {
  try {
    const { type, category, amount, description, date } = req.body;
    
    const result = await query(
      `INSERT INTO financial_transactions (type, category, amount, description, date) 
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [type, category, amount, description, date]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao criar transação:', error);
    res.status(500).json({ error: 'Erro ao criar transação financeira' });
  }
});

// DELETE /api/financial/transactions/:id - Deletar transação
router.delete('/transactions/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await query(
      'DELETE FROM financial_transactions WHERE id = $1 RETURNING *',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Transação não encontrada' });
    }

    res.json({ message: 'Transação excluída com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir transação:', error);
    res.status(500).json({ error: 'Erro ao excluir transação financeira' });
  }
});

module.exports = router;