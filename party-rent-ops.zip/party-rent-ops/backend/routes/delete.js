const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// DELETE /api/delete/orders/:id - Excluir ordem de serviço
router.delete('/orders/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar se a ordem existe
    const orderResult = await query('SELECT * FROM orders WHERE id = $1', [id]);
    if (orderResult.rows.length === 0) {
      return res.status(404).json({ error: 'Ordem de serviço não encontrada' });
    }

    // Restaurar disponibilidade dos produtos
    const orderItemsResult = await query(
      'SELECT product_id, quantity FROM order_items WHERE order_id = $1',
      [id]
    );

    for (const item of orderItemsResult.rows) {
      await query(
        'UPDATE products SET available = available + $1 WHERE id = $2',
        [item.quantity, item.product_id]
      );
    }

    // Excluir a ordem (cascade vai excluir items, payments, agenda_events automaticamente)
    await query('DELETE FROM orders WHERE id = $1', [id]);
    
    res.json({ message: 'Ordem de serviço excluída com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir ordem de serviço:', error);
    res.status(500).json({ error: 'Erro ao excluir ordem de serviço' });
  }
});

// DELETE /api/delete/clients/:id - Excluir cliente
router.delete('/clients/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar se o cliente existe
    const clientResult = await query('SELECT * FROM clients WHERE id = $1', [id]);
    if (clientResult.rows.length === 0) {
      return res.status(404).json({ error: 'Cliente não encontrado' });
    }

    // Verificar se existem ordens para este cliente
    const ordersResult = await query('SELECT COUNT(*) as count FROM orders WHERE client_id = $1', [id]);
    if (parseInt(ordersResult.rows[0].count) > 0) {
      return res.status(400).json({ 
        error: 'Não é possível excluir cliente com ordens de serviço associadas' 
      });
    }

    // Excluir o cliente
    await query('DELETE FROM clients WHERE id = $1', [id]);
    
    res.json({ message: 'Cliente excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir cliente:', error);
    res.status(500).json({ error: 'Erro ao excluir cliente' });
  }
});

// DELETE /api/delete/products/:id - Excluir produto
router.delete('/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar se o produto existe
    const productResult = await query('SELECT * FROM products WHERE id = $1', [id]);
    if (productResult.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    // Verificar se existem itens de ordem para este produto
    const orderItemsResult = await query('SELECT COUNT(*) as count FROM order_items WHERE product_id = $1', [id]);
    if (parseInt(orderItemsResult.rows[0].count) > 0) {
      return res.status(400).json({ 
        error: 'Não é possível excluir produto com ordens de serviço associadas' 
      });
    }

    // Excluir o produto
    await query('DELETE FROM products WHERE id = $1', [id]);
    
    res.json({ message: 'Produto excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir produto:', error);
    res.status(500).json({ error: 'Erro ao excluir produto' });
  }
});

// DELETE /api/delete/agenda/:id - Excluir evento da agenda
router.delete('/agenda/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar se o evento existe
    const eventResult = await query('SELECT * FROM agenda_events WHERE id = $1', [id]);
    if (eventResult.rows.length === 0) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }

    // Excluir o evento
    await query('DELETE FROM agenda_events WHERE id = $1', [id]);
    
    res.json({ message: 'Evento excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir evento:', error);
    res.status(500).json({ error: 'Erro ao excluir evento' });
  }
});

// DELETE /api/delete/financial/:id - Excluir transação financeira
router.delete('/financial/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar se a transação existe
    const transactionResult = await query('SELECT * FROM financial_transactions WHERE id = $1', [id]);
    if (transactionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Transação não encontrada' });
    }

    // Excluir a transação
    await query('DELETE FROM financial_transactions WHERE id = $1', [id]);
    
    res.json({ message: 'Transação excluída com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir transação:', error);
    res.status(500).json({ error: 'Erro ao excluir transação' });
  }
});

// PUT /api/delete/payments/:id/mark-paid - Marcar pagamento como pago
router.put('/payments/:id/mark-paid', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar se o pagamento existe
    const paymentResult = await query('SELECT * FROM payments WHERE id = $1', [id]);
    if (paymentResult.rows.length === 0) {
      return res.status(404).json({ error: 'Pagamento não encontrado' });
    }

    // Marcar como pago
    const result = await query(
      'UPDATE payments SET status = $1, paid_date = CURRENT_DATE WHERE id = $2 RETURNING *',
      ['pago', id]
    );
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao marcar pagamento como pago:', error);
    res.status(500).json({ error: 'Erro ao marcar pagamento como pago' });
  }
});

module.exports = router;