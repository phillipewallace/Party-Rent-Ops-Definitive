const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// GET /api/reports/financial - Relatório financeiro
router.get('/financial', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    const result = await query(`
      SELECT 
        type,
        category,
        SUM(amount) as total,
        COUNT(*) as count
      FROM financial_transactions 
      WHERE date BETWEEN $1 AND $2
      GROUP BY type, category
      ORDER BY type, total DESC
    `, [startDate || '2024-01-01', endDate || '2024-12-31']);

    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao gerar relatório:', error);
    res.status(500).json({ error: 'Erro ao gerar relatório financeiro' });
  }
});

module.exports = router;