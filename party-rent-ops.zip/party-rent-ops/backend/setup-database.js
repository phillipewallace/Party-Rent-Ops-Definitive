const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config();

// Configuração do banco para criação inicial
const adminPool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: 'postgres', // conecta no banco padrão para criar o banco do ERP
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'admin123',
});

// Pool para o banco do ERP após criação
const erpPool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'erp_database',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'admin123',
});

async function setupDatabase() {
  try {
    console.log('🔧 Iniciando setup do banco de dados...');

    // 1. Criar banco de dados se não existir
    const dbName = process.env.DB_NAME || 'erp_database';
    console.log(`📊 Verificando banco: ${dbName}`);
    
    try {
      const checkDB = await adminPool.query(
        'SELECT 1 FROM pg_database WHERE datname = $1',
        [dbName]
      );
      
      if (checkDB.rows.length === 0) {
        await adminPool.query(`CREATE DATABASE ${dbName}`);
        console.log(`✅ Banco ${dbName} criado com sucesso!`);
      } else {
        console.log(`ℹ️  Banco ${dbName} já existe`);
      }
    } catch (error) {
      console.error('❌ Erro ao criar banco:', error.message);
      throw error;
    }
    
    await adminPool.end();

    // 2. Executar schema
    console.log('📋 Criando tabelas...');
    const schemaSQL = fs.readFileSync(path.join(__dirname, 'database', 'schema.sql'), 'utf8');
    await erpPool.query(schemaSQL);
    console.log('✅ Tabelas criadas com sucesso!');

    // 3. Inserir dados iniciais
    console.log('🌱 Inserindo dados iniciais...');
    const seedSQL = fs.readFileSync(path.join(__dirname, 'database', 'seed.sql'), 'utf8');
    await erpPool.query(seedSQL);
    console.log('✅ Dados iniciais inseridos!');

    // 4. Testar conexão
    console.log('🧪 Testando conexão...');
    const testResult = await erpPool.query('SELECT COUNT(*) as total FROM products');
    console.log(`✅ Teste concluído! ${testResult.rows[0].total} produtos encontrados`);

    console.log('\n🎉 Setup do banco concluído com sucesso!');
    console.log('📊 Banco pronto para uso');
    
  } catch (error) {
    console.error('❌ Erro durante setup:', error);
    process.exit(1);
  } finally {
    await erpPool.end();
  }
}

// Executar setup se chamado diretamente
if (require.main === module) {
  setupDatabase();
}

module.exports = { setupDatabase };