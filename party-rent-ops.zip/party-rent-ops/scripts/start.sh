#!/bin/bash

echo "============================================"
echo "        INICIANDO SISTEMA ERP"
echo "============================================"
echo

# Verificar se Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "ERRO: Node.js não encontrado!"
    echo "Instale Node.js primeiro"
    exit 1
fi

# Verificar se PostgreSQL está rodando
if ! pg_isready -h localhost -p 5432 &> /dev/null; then
    echo "PostgreSQL não está rodando. Tentando iniciar..."
    sudo systemctl start postgresql &> /dev/null || sudo service postgresql start &> /dev/null
    sleep 3
fi

echo "[1/2] Iniciando servidor backend..."
cd backend
gnome-terminal --title="ERP Backend" -- bash -c "npm start; exec bash" &
cd ..

sleep 5

echo "[2/2] Iniciando interface web..."
gnome-terminal --title="ERP Frontend" -- bash -c "npm run dev; exec bash" &

sleep 8

echo
echo "============================================"
echo "         SISTEMA INICIADO!"
echo "============================================"
echo

# Tentar abrir Chrome primeiro, depois Firefox
echo "Abrindo navegador..."
if command -v google-chrome &> /dev/null; then
    google-chrome http://localhost:5173 &> /dev/null &
    echo "Sistema aberto no Google Chrome"
elif command -v chromium-browser &> /dev/null; then
    chromium-browser http://localhost:5173 &> /dev/null &
    echo "Sistema aberto no Chromium"
elif command -v firefox &> /dev/null; then
    firefox http://localhost:5173 &> /dev/null &
    echo "Sistema aberto no Firefox"
else
    echo "Navegador não encontrado automaticamente"
    echo "Abra manualmente: http://localhost:5173"
fi

echo "Sistema rodando em: http://localhost:5173"
echo "Pressione Ctrl+C para parar"
wait