# 🚀 ERP System - Guia de Instalação Completa

## 📋 Pré-requisitos

### Softwares Necessários:
1. **Node.js 18+** - https://nodejs.org/
2. **PostgreSQL 15+** - https://www.postgresql.org/download/
3. **Git** (opcional) - https://git-scm.com/

### Requisitos de Sistema:
- Windows 10/11
- 4GB RAM mínimo
- 2GB espaço livre

---

## 🗄️ Configuração do PostgreSQL

### 1. Instalação do PostgreSQL
1. Baixe o PostgreSQL em: https://www.postgresql.org/download/windows/
2. Durante a instalação:
   - **Porta**: `5432` (padrão)
   - **Senha do postgres**: `admin123` (ou anote a sua)
   - **Locale**: Portuguese, Brazil

### 2. Criar a Database
1. Abra o **pgAdmin** ou **psql**
2. Execute o arquivo `create-database.sql`:
   ```bash
   # Via psql (linha de comando)
   psql -U postgres -f create-database.sql
   
   # Ou copie e cole o conteúdo no pgAdmin
   ```

### 3. Verificar Conexão
```bash
# Testar se PostgreSQL está rodando
pg_isready -h localhost -p 5432

# Se não estiver, iniciar o serviço
net start postgresql-x64-15
```

---

## ⚙️ Configuração do Projeto

### 1. Clonar/Baixar o Projeto
```bash
git clone [url-do-projeto]
cd erp-system
```

### 2. Configurar Backend
```bash
# Entrar na pasta backend
cd backend

# Copiar arquivo de configuração
copy .env.example .env

# Instalar dependências
npm install
```

### 3. Configurar arquivo .env
Edite o arquivo `backend/.env`:
```env
# Configurações do Banco
DB_HOST=localhost
DB_PORT=5432
DB_NAME=erp_database
DB_USER=postgres
DB_PASSWORD=admin123

# Configurações do Servidor
PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:5173

# JWT Secret
JWT_SECRET=seu_jwt_secret_super_seguro_aqui_12345

# Upload settings
UPLOAD_PATH=./uploads
MAX_FILE_SIZE=10485760
```

### 4. Configurar Frontend
```bash
# Voltar para pasta raiz
cd ..

# Instalar dependências
npm install
```

---

## 🚀 Iniciando o Sistema

### Método Simples (Recomendado):
1. **Execute**: `start.bat`
2. **Aguarde**: O sistema abrirá automaticamente no navegador
3. **Acesse**: http://localhost:5173

### Método Manual:
```bash
# Terminal 1 - Backend
cd backend
npm start

# Terminal 2 - Frontend (nova janela)
npm run dev
```

---

## 🌐 Acessando o Sistema

- **Frontend**: http://localhost:5173
- **API**: http://localhost:3001
- **Health Check**: http://localhost:3001/api/health

### Credenciais de Teste:
- Sistema não possui login ainda
- Dados de exemplo já inclusos na database

---

## 📂 Estrutura de Pastas

```
erp-system/
├── backend/                    # API Node.js
│   ├── config/                # Configurações
│   ├── database/              # Schemas
│   ├── routes/                # Rotas da API
│   ├── uploads/              # Arquivos enviados
│   ├── .env                  # Configurações
│   └── server.js             # Servidor principal
├── src/                       # Frontend React
│   ├── components/           # Componentes
│   ├── pages/               # Páginas
│   └── services/            # Chamadas API
├── create-database.sql       # Script da database
├── start.bat                # Script de inicialização
└── package.json             # Dependências frontend
```

---

## 🔧 Comandos Úteis

### Backend:
```bash
cd backend
npm start          # Iniciar servidor
npm run dev        # Modo desenvolvimento (com reload)
npm run setup      # Configurar database
```

### Frontend:
```bash
npm run dev        # Servidor desenvolvimento
npm run build      # Build para produção
npm run preview    # Preview do build
```

### Database:
```bash
# Backup da database
pg_dump -U postgres erp_database > backup.sql

# Restaurar backup
psql -U postgres erp_database < backup.sql

# Conectar via psql
psql -U postgres -d erp_database
```

---

## 🚨 Solução de Problemas

### PostgreSQL não conecta:
```bash
# Verificar se está rodando
pg_isready -h localhost -p 5432

# Iniciar serviço
net start postgresql-x64-15

# Verificar porta
netstat -an | findstr :5432
```

### Erro "Porta em uso":
```bash
# Verificar processo na porta 3001
netstat -ano | findstr :3001

# Matar processo
taskkill /PID [número] /F
```

### Node.js não encontrado:
1. Reinstale o Node.js
2. Reinicie o terminal
3. Verifique: `node --version`

### Database não existe:
1. Execute novamente o `create-database.sql`
2. Verifique credenciais no `.env`
3. Teste conexão: `psql -U postgres`

---

## 📊 Funcionalidades do Sistema

### ✅ Módulos Funcionais:
- **Dashboard**: Métricas e resumos
- **Produtos**: Cadastro completo
- **Clientes**: Gestão de dados
- **Ordens de Serviço**: Controle de locações
- **Financeiro**: Receitas e despesas
- **Agenda**: Eventos e entregas
- **Relatórios**: Análises

### 🔧 Recursos Técnicos:
- **Frontend**: React + TypeScript + Tailwind
- **Backend**: Node.js + Express
- **Database**: PostgreSQL
- **API**: REST com validação
- **Upload**: Sistema de arquivos

---

## 🎯 Primeiros Passos

1. **Execute**: `start.bat`
2. **Acesse**: http://localhost:5173
3. **Explore**: Dashboard com dados de exemplo
4. **Cadastre**: Novos produtos e clientes
5. **Crie**: Sua primeira ordem de serviço

---

## 📞 Suporte

### Logs do Sistema:
- **Backend**: Console do terminal
- **Frontend**: F12 > Console
- **Database**: pgAdmin logs

### Comandos de Diagnóstico:
```bash
# Status dos serviços
sc query postgresql-x64-15

# Processos Node.js
tasklist | findstr node

# Teste da API
curl http://localhost:3001/api/health
```

---

## ✅ Sistema Pronto!

**Frontend**: http://localhost:5173  
**API**: http://localhost:3001  
**Admin DB**: pgAdmin  

> Sistema ERP completo funcionando 100% local!